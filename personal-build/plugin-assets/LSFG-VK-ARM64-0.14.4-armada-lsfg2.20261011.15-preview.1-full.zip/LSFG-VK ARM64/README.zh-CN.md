# LSFG-VK ARM64

[English](README.md) | **简体中文**

面向 **Armada ARM64** 的 Decky 补帧插件，基于 [Decky LSFG-VK](https://github.com/xXJSONDeruloXx/decky-lsfg-vk)。内置修改过的 ARM64 lsfg-vk 2.0 运行组件，提供简体中文界面，可与原版插件同时安装。

[下载最新发布版](https://github.com/mydanyi/decky-lsfg-vk-arm64/releases/latest)

## 功能

- 分别管理 Steam 游戏、非 Steam 快捷方式和支持的 ARM64 Flatpak 应用，提供批量操作与“正在运行”页面。
- 固定模式支持 2～6 倍补帧；目标模式可设置目标 FPS 与 2～4 倍的最高倍率。切换模式会保留两组设置，固定模式的 1 倍表示关闭补帧。
- 基础 FPS 上限支持 0（不由插件限帧）至 72，通过 DXVK / VKD3D 启动路径应用于 D3D9、D3D10、D3D11 和 D3D12。
- 性能模式默认开启，明确保存的关闭设置仍保留。“过载退让与帧节奏恢复”适用于目标 FPS 模式；固定模式保留选定倍率，支持 2～6 倍的提交节奏平滑。
- 按游戏自动配置启动参数，使用可迁移的 `~/.lsfg-arm64` 路径。升级期间仍支持已有的 `~/lsfg-arm64` 启动参数。
- 光流比例、性能模式、呈现模式覆盖、交换链图像数量及按游戏设置的兼容选项。
- 完整插件 ZIP 内置 ARM64 核心、命令行工具和配置工具，由插件自动安装运行组件。
- 独立的插件名称、配置、启动脚本、原生工具及 Vulkan 图层，可与 **Decky LSFG-VK** 共存。
- 使用 GPU 补帧。目标 FPS 是调度目标，不代表所有场景都能达到该帧率或保证屏幕的实际显示间隔。

## 安装与使用

需要 Armada ARM64、已安装的 Decky，以及 Steam 上的正版 **Lossless Scaling**。

1. 在 Steam 中打开 **Lossless Scaling → 属性 → 游戏版本与测试版**（部分客户端显示为“测试版”），选择 **`lsfg-vk`** 分支，等待下载或更新完成。该分支提供所需的 `lsfg-vk.dll`，可参考 [lsfg-vk 官方安装说明](https://lsfg-vk.dev/docs/installation/)。
2. 从 [Releases](https://github.com/mydanyi/decky-lsfg-vk-arm64/releases/latest) 下载完整插件 ZIP，在 Decky 开发者设置中安装。GitHub 自动生成的 Source code 文件只是源码包。
3. 打开或重新加载 **LSFG-VK ARM64**，等待运行组件自动安装，并确认 Lossless Scaling 检测成功。“设置”页面提供分支设置指引。
4. 在 Steam 或非 Steam 页面选择游戏，启用其配置。插件会添加自己的启动脚本，并保留无关启动参数。支持的 Flatpak 应用通过 Flatpak 页面管理。
5. 选择固定模式或目标模式，再按需设置基础 FPS 上限及兼容选项。更改启动参数、限帧或 Flatpak 权限后，请重启游戏。

同一游戏使用一套补帧插件的启动配置。两个插件分别保存设置；本插件不会自动为所有游戏启用补帧、导入原版配置或删除原版插件。接管已使用其他补帧启动脚本的游戏时，请检查生成的启动参数。

发布包包含修改过的 ARM64 运行组件，不包含商业文件 `lsfg-vk.dll`。请通过上述 Steam 分支取得，不能把旧版 `Lossless.dll` 改名替代。曾安装仅含插件的包时，应使用完整 ZIP 更新；发布页附带 `SHA256SUMS.txt` 时，可用它核对下载文件。

## Flatpak

Flatpak 集成采用独立的用户级 ARM64 Vulkan 扩展，支持 Freedesktop 24.08、25.08，以及基于这些运行时的兼容 GNOME / KDE 应用。使用插件内置的 ARM64 核心，不下载原版 x86 核心；仍需兼容的 Vulkan 驱动及可访问的 DLL。

应用配置和兼容选项分别记录。移除应用配置时，只恢复本插件修改过的覆盖设置，保留无关设置及用户后续修改，也不会删除原版插件的扩展。已运行的 Flatpak 应用可能需要重启才能读取新配置。

设置页显示从 `package.json` 读取的插件版本。参见[预览版版本管理](docs/PREVIEW-VERSIONING.md)和 [r15 改动记录](docs/CHANGELOG-r15.md)。

## 开发

仓库包含 Decky 插件以及[原生运行组件补丁和构建说明](native/README.md)。前端构建生成 `dist/index.js`，不会编译原生核心。请使用已提交的依赖锁文件；后端开发需要 Linux、Python 3.11+ 和 Bash。

```sh
pnpm install --frozen-lockfile
pnpm test
pnpm exec tsc --noEmit
pnpm build
python3 -m unittest discover -s tests -v
```

安装包根目录为 `LSFG-VK ARM64`。完整包内的 `bin/lsfg-vk-arm64-2.0.0.tar.xz` 包含核心、命令行工具、配置工具、图层清单、桌面入口和图标，同时保留 `bin/liblsfg-vk-v2-arm64.so` 核心产物。文件布局和许可要求见原生构建说明。

## 致谢与许可

本社区分支基于 [xXJSONDeruloXx/decky-lsfg-vk](https://github.com/xXJSONDeruloXx/decky-lsfg-vk)，保留 Kurt Himebauch 及其他贡献者的 BSD-3-Clause 许可与声明，详见 [LICENSE](LICENSE)。仓库保留[上游 README](docs/UPSTREAM-README.md) 作为来源和历史参考。

[lsfg-vk](https://lsfg-vk.dev/) 原生组件使用独立的 CC BY-NC-ND 4.0 许可，发布包包含其许可文件。插件外壳的许可不覆盖原生组件；Lossless Scaling 及其 DLL 遵循各自条款。

感谢原插件作者、lsfg-vk 贡献者、Lossless Scaling 开发者、Decky Loader 团队及 Armada 贡献者。本分支的问题请提交到[本仓库](https://github.com/mydanyi/decky-lsfg-vk-arm64/issues)。

## 支持与交流

特别感谢 **深圳市退格科技有限公司** 为本项目提供资金支持，帮助我们持续推进 LSFG-VK ARM64 的开发、测试与维护。

- 赞助：[爱发电](https://afdian.com/a/meetmiku)
- QQ 粉丝群：**487945399**
- QQ 闲聊群：**477426414**
