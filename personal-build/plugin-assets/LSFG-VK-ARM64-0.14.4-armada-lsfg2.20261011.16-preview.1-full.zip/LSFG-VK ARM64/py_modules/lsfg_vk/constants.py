from pathlib import Path

LOCAL_BIN = ".local/bin"
LOCAL_SHARE = ".local/share"
LOCAL_LIB = ".local/lib"
VULKAN_LAYER_DIR = ".local/share/vulkan/implicit_layer.d"
CONFIG_DIR = ".config/lsfg-vk-arm64"

SCRIPT_NAME = "lsfg-arm64"
WRAPPER_FILENAME = ".lsfg-arm64"
CONFIG_FILENAME = "conf-v2.toml"
ARCHIVE_FILENAME = "lsfg-vk-arm64-2.0.0.tar.xz"
LIB_FILENAME = "liblsfg-vk-arm64.so"
LIB_X86_FILENAME = "liblsfg-vk-arm64.x86.so"
JSON_FILENAME = "VkLayer_LSFGVK_ARM64_frame_generation.json"
JSON_X86_FILENAME = "VkLayer_LSFGVK_ARM64_frame_generation.x86.json"
CLI_FILENAME = "lsfg-vk-arm64-cli"
UI_FILENAME = "lsfg-vk-arm64-ui"
UI_DESKTOP_FILENAME = "gay.pancake.lsfg-vk-arm64-ui.desktop"
UI_ICON_FILENAME = "gay.pancake.lsfg-vk-arm64-ui.png"
STEAM_LOSSLESS_SCALING_APP_ID = "993090"
STEAM_LOSSLESS_SCALING_BRANCH = "lsfg-vk"

LEGACY_LIB_FILENAME = "liblsfg-vk-v1-arm64.so"
LEGACY_JSON_FILENAME = "VkLayer_LS_ARM64_frame_generation.json"

BIN_DIR = "bin"

STEAM_COMMON_PATH = Path("steamapps/common/Lossless Scaling")
ENV_LSFG_DLL_PATH = "LSFG_DLL_PATH"
ENV_XDG_DATA_HOME = "XDG_DATA_HOME"
ENV_HOME = "HOME"
LSFG_VK_DLL_NAME = "lsfg-vk.dll"