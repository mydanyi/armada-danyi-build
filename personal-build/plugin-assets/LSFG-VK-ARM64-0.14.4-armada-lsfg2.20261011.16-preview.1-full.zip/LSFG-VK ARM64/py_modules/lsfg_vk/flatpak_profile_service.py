from __future__ import annotations

import contextlib
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Tuple

from .configuration import ConfigurationService
from .flatpak_service import FlatpakService
from .wrapper_service import WrapperService


class FlatpakProfileService:
    """Per-app Flatpak workaround profiles layered on the shared FlatpakService.

    The upstream ``FlatpakService`` owns whole-app override preparation and the
    segment-level ownership records.  This service only layers the per-app
    workaround scalars, the frame-rate cap and the native lsfg-vk profile on top
    of that preparation, reusing the exact workaround semantics (and state
    validation) of ``WrapperService`` so the sandboxed and native paths stay in
    sync.
    """

    STATE_FIELDS = WrapperService.STATE_FIELDS
    OPTIONAL_BOOLEAN_FIELDS = WrapperService.OPTIONAL_BOOLEAN_FIELDS
    BOOLEAN_FIELDS = WrapperService.BOOLEAN_FIELDS

    # Environment override fields this service owns and must virtually undo
    # before re-deriving the desired workaround values.  These are the
    # workaround scalars plus the frame-rate cap; the plugin preparation keys
    # (LSFGVK_CONFIG/LSFGVK_PROFILE/...) are intentionally excluded so their
    # ownership records survive.
    _MANAGED_WORKAROUND_FIELDS: Tuple[Tuple[str, str], ...] = (
        ("Environment", "ENABLE_GAMESCOPE_WSI"),
        ("Environment", "DISABLE_GAMESCOPE_WSI"),
        ("Environment", "DXVK_HDR"),
        ("Environment", "SteamDeck"),
        ("Environment", "DISABLE_VKBASALT"),
        ("Environment", "ENABLE_VKBASALT"),
        ("Environment", "__GLX_VENDOR_LIBRARY_NAME"),
        ("Environment", "MESA_LOADER_DRIVER_OVERRIDE"),
        ("Environment", "GALLIUM_DRIVER"),
        ("Environment", "PROTON_USE_WOW64"),
        ("Environment", "MANGOHUD"),
        ("Environment", "DXVK_FRAME_RATE"),
        ("Environment", "VKD3D_FRAME_RATE"),
        ("Environment", "DXVK_CONFIG"),
    )

    _DXVK_CONFIG_KEYS = (
        "dxvk.maxFrameRate",
        "dxgi.maxFrameRate",
        "d3d9.maxFrameRate",
    )

    def __init__(
        self,
        flatpak_service: FlatpakService,
        configuration_service: ConfigurationService,
    ):
        self.flatpak_service = flatpak_service
        self.configuration_service = configuration_service

    # ------------------------------------------------------------------
    # State validation (shared with the native wrapper workarounds)
    # ------------------------------------------------------------------

    @classmethod
    def default_state(cls) -> Dict[str, Any]:
        return WrapperService.default_state()

    @classmethod
    def _validate_state(cls, raw: Any) -> Dict[str, Any]:
        return WrapperService._validate_state(raw)

    def _state_entry(self, app_id: str) -> tuple[Dict[str, object], Dict[str, Any]]:
        state = self.flatpak_service._read_state()
        entry = state["prepared_apps"].get(app_id)
        if not isinstance(entry, dict):
            raise RuntimeError("Flatpak application is not owned by this plugin")
        return state, entry

    def _stored_workarounds(self, app_id: str) -> Dict[str, Any]:
        _, entry = self._state_entry(app_id)
        stored = entry.get("workaround_state")
        if isinstance(stored, dict):
            return WrapperService._validate_state(stored)
        return WrapperService.default_state()

    # ------------------------------------------------------------------
    # Transaction: snapshot the three plugin-owned files and roll them back
    # exactly on any failure so success is never claimed falsely.
    # ------------------------------------------------------------------

    @staticmethod
    def _read_text(path: Path) -> Optional[str]:
        if path.is_symlink():
            raise RuntimeError(f"{path} is not a regular file")
        if not path.exists():
            return None
        if not path.is_file():
            raise RuntimeError(f"{path} is not a regular file")
        return path.read_text(encoding="utf-8")

    def _restore_text(self, path: Path, text: Optional[str]) -> None:
        if text is None:
            path.unlink(missing_ok=True)
            return
        self.configuration_service._write_file(path, text, 0o644)

    def _capture_owned_branches(self, errors: List[str]) -> set:
        """Capture branches whose directory carries a valid ownership marker.

        A branch is only retained when the existing ``_owned_marker`` validates,
        so a foreign or shared extension directory can never be claimed (and no
        branch directory is ever deleted here).
        """
        live: set = set()
        for branch in self.flatpak_service.SUPPORTED_RUNTIMES:
            try:
                directory = self.flatpak_service._branch_dir(branch)
                if directory.is_symlink() or not directory.is_dir():
                    continue
                if self.flatpak_service._owned_marker(branch) is not None:
                    live.add(branch)
            except Exception as error:
                errors.append(f"owned branch scan for {branch}: {error}")
        return live

    def _reconcile_owned_branches(self, live_owned: set) -> None:
        """Union verified owned branches back into the restored ownership state.

        ``prepared_apps`` is left exactly as the snapshot restored it; only the
        owned branch list can grow. When nothing was added the restored file is
        left byte-for-byte untouched.
        """
        flatpak = self.flatpak_service
        restored = flatpak._read_state()
        snapshot_owned = flatpak._owned_branches(restored)
        union = snapshot_owned | live_owned
        if union == snapshot_owned:
            return
        restored["plugin_owned_branches"] = sorted(union)
        flatpak._write_state(restored)

    @contextlib.contextmanager
    def _transaction(self, app_id: str) -> Iterator[None]:
        """Hold the Flatpak lock and restore the three owned files on failure."""
        flatpak = self.flatpak_service
        app_id = flatpak._validate_app_id(app_id)
        config_path = self.configuration_service.config_file_path
        override_path = flatpak._override_path(app_id)
        ownership_path = flatpak.ownership_path
        with flatpak._lock:
            snapshots = (
                (config_path, self._read_text(config_path), False),
                (override_path, flatpak._read_override_text(app_id), True),
                (ownership_path, self._read_text(ownership_path), False),
            )
            try:
                yield
            except Exception as failure:
                rollback_errors: List[str] = []
                # Capture owned branches before the snapshot restore rewinds the
                # ownership metadata, so a freshly installed extension stays
                # plugin-owned and removable even though the transaction failed.
                live_owned = self._capture_owned_branches(rollback_errors)
                for path, text, is_override in snapshots:
                    try:
                        if is_override:
                            flatpak._restore_override_text(app_id, text)
                        else:
                            self._restore_text(path, text)
                    except Exception as rollback_error:
                        rollback_errors.append(f"{path}: {rollback_error}")
                try:
                    self._reconcile_owned_branches(live_owned)
                except Exception as rollback_error:
                    rollback_errors.append(f"{ownership_path}: {rollback_error}")
                if rollback_errors:
                    raise RuntimeError(
                        f"{failure}; rollback also failed: " + "; ".join(rollback_errors)
                    ) from failure
                raise

    # ------------------------------------------------------------------
    # Override derivation
    # ------------------------------------------------------------------

    @staticmethod
    def _environment_value(content: str, key: str) -> str:
        section = None
        for raw_line in content.splitlines():
            line = raw_line.strip()
            if line.startswith("[") and line.endswith("]"):
                section = line[1:-1]
                continue
            if section != "Environment":
                continue
            name, separator, value = line.partition("=")
            if separator and name == key:
                return value
        return ""

    def _dxvk_config_value(self, app_id: str, frame_rate: int) -> str:
        """Merge the three frame-rate keys into the user's DXVK_CONFIG segments."""
        base = self.flatpak_service._base_override_value(app_id, "Environment", "DXVK_CONFIG")
        segments = self.flatpak_service._split_list_value(base, ";")
        replaced = set()
        merged: List[str] = []
        for segment in segments:
            key = segment.split("=", 1)[0].strip()
            if key in self._DXVK_CONFIG_KEYS:
                if key in replaced:
                    continue
                replaced.add(key)
                merged.append(f"{key} = {frame_rate}")
            else:
                merged.append(segment)
        for key in self._DXVK_CONFIG_KEYS:
            if key not in replaced:
                merged.append(f"{key} = {frame_rate}")
        return "; ".join(merged)

    def _workaround_environment(self, state: Dict[str, Any]) -> Dict[str, Optional[str]]:
        values: Dict[str, Optional[str]] = {}
        values["ENABLE_GAMESCOPE_WSI"] = "0" if state["disableGamescopeWsi"] else "1"
        values["DISABLE_GAMESCOPE_WSI"] = None
        if state["disableHdr"]:
            values["DXVK_HDR"] = "0"
        if state["disableSteamdeckMode"]:
            values["SteamDeck"] = "0"
        if state["disableVkbasalt"]:
            values["DISABLE_VKBASALT"] = "1"
            values["ENABLE_VKBASALT"] = None
        elif state["forceEnableVkbasalt"]:
            values["ENABLE_VKBASALT"] = "1"
            values["DISABLE_VKBASALT"] = None
        if state["enableZink"]:
            values["__GLX_VENDOR_LIBRARY_NAME"] = "mesa"
            values["MESA_LOADER_DRIVER_OVERRIDE"] = "zink"
            values["GALLIUM_DRIVER"] = "zink"
        if state["enableWow64"]:
            values["PROTON_USE_WOW64"] = "1"
        if state["mangohudWorkaround"]:
            values["MANGOHUD"] = "1"
        return values

    def _desired_values(
        self,
        app_id: str,
        state: Dict[str, Any],
        generation_mode: str,
        multiplier: int,
    ) -> Dict[str, Dict[str, Optional[str]]]:
        flatpak = self.flatpak_service
        prepared = flatpak._prepare_values(app_id)
        environment: Dict[str, Optional[str]] = dict(prepared["Environment"])
        environment.update(self._workaround_environment(state))
        frame_rate = state["dxvkFrameRate"]
        if frame_rate > 0:
            environment["DXVK_FRAME_RATE"] = str(frame_rate)
            environment["VKD3D_FRAME_RATE"] = str(frame_rate)
            environment["DXVK_CONFIG"] = self._dxvk_config_value(app_id, frame_rate)
        # A fixed profile at multiplier 1 must clear our activation guard while
        # target mode stays enabled even if a fixed multiplier of 1 was saved.
        if not (generation_mode == "target" or multiplier > 1):
            environment[flatpak.ACTIVATION_ENV] = None
        unset_tokens = flatpak._split_list_value(
            prepared["Context"]["unset-environment"], ";"
        )
        for key, value in environment.items():
            if value is None:
                if key not in unset_tokens:
                    unset_tokens.append(key)
            else:
                unset_tokens = [token for token in unset_tokens if token != key]
        return {
            "Context": {
                "filesystems": prepared["Context"]["filesystems"],
                "unset-environment": ";".join(unset_tokens),
            },
            "Environment": environment,
        }

    # ------------------------------------------------------------------
    # State application
    # ------------------------------------------------------------------

    def _apply_state(self, app_id: str, workaround_state: Dict[str, Any]) -> Dict[str, Any]:
        app_id = self.flatpak_service._validate_app_id(app_id)
        state = WrapperService._validate_state(workaround_state)
        self._state_entry(app_id)
        with self._transaction(app_id):
            config_result = self.configuration_service.get_flatpak_config(app_id)
            if not config_result.get("success"):
                raise RuntimeError(
                    config_result.get("error") or f"Could not read Flatpak profile for {app_id}"
                )
            if not config_result.get("exists"):
                raise RuntimeError(f"Flatpak profile for {app_id} does not exist")
            config = dict(config_result["config"])
            if config.get("recovery_base_fps") != state["dxvkFrameRate"]:
                config["recovery_base_fps"] = state["dxvkFrameRate"]
                saved = self.configuration_service.update_flatpak_config(app_id, config)
                if not saved.get("success"):
                    raise RuntimeError(
                        saved.get("error") or f"Could not update Flatpak profile for {app_id}"
                    )
                config = dict(saved["config"])
            generation_mode = str(config.get("generation_mode", "fixed"))
            multiplier = int(config.get("multiplier", 1) or 1)
            # Undo only our previous workaround contributions so the user's own
            # environment values survive, then re-derive and apply in one pass.
            self.flatpak_service._restore_owned_overrides(
                app_id, fields=self._MANAGED_WORKAROUND_FIELDS
            )
            self.flatpak_service._apply_owned_overrides(
                app_id,
                self._desired_values(app_id, state, generation_mode, multiplier),
            )
            if not self.flatpak_service._app_override_status(app_id)["prepared"]:
                raise RuntimeError(f"Flatpak preparation did not become visible for {app_id}")
            ownership = self.flatpak_service._read_state()
            entry = ownership["prepared_apps"].get(app_id)
            if not isinstance(entry, dict):
                raise RuntimeError("Flatpak application ownership state disappeared")
            entry["workaround_state"] = state
            self.flatpak_service._write_state(ownership)
        return state

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def enable_app(self, app_id: str) -> Dict[str, Any]:
        try:
            app_id = self.flatpak_service._validate_app_id(app_id)
            existing = self.configuration_service.get_flatpak_config(app_id)
            if not existing.get("success"):
                raise RuntimeError(
                    existing.get("error") or f"Could not read Flatpak profile for {app_id}"
                )
            with self._transaction(app_id):
                prepared = self.flatpak_service.prepare_app(app_id)
                if not prepared.get("success"):
                    raise RuntimeError(prepared.get("error") or "Could not prepare Flatpak application")
                if not prepared.get("owned"):
                    raise RuntimeError(
                        "Flatpak application is prepared outside this plugin and cannot be managed safely"
                    )
                _, entry = self._state_entry(app_id)
                if existing.get("exists"):
                    profile_config = dict(existing["config"])
                else:
                    config = {
                        **self.configuration_service._public_config({}),
                        **(existing.get("global_config") or {}),
                    }
                    config["active_in"] = []
                    saved = self.configuration_service.update_flatpak_config(app_id, config)
                    if not saved.get("success"):
                        raise RuntimeError(saved.get("error") or "Could not create Flatpak profile")
                    profile_config = dict(saved["config"])
                stored = entry.get("workaround_state")
                if isinstance(stored, dict):
                    workaround_state = WrapperService._validate_state(stored)
                else:
                    workaround_state = WrapperService.default_state()
                    # A saved native base FPS is trusted verbatim: an
                    # out-of-range or non-integer value is rejected by
                    # _validate_state and rolled back, never silently rewritten.
                    workaround_state["dxvkFrameRate"] = profile_config.get(
                        "recovery_base_fps", 0
                    )
                    workaround_state = WrapperService._validate_state(workaround_state)
                self._apply_state(app_id, workaround_state)
                result = self.get_app(app_id)
                if not result.get("success"):
                    raise RuntimeError(
                        result.get("error") or "Could not read Flatpak application"
                    )
            return result
        except Exception as error:
            return {
                "success": False,
                "message": "",
                "error": str(error),
                "app_id": str(app_id),
                "enabled": False,
            }

    def update_config(self, app_id: str, config: Dict[str, Any]) -> Dict[str, Any]:
        try:
            app_id = self.flatpak_service._validate_app_id(app_id)
            result: Dict[str, Any] = {}
            with self._transaction(app_id):
                self._state_entry(app_id)
                saved = self.configuration_service.update_flatpak_config(app_id, config)
                if not saved.get("success"):
                    raise RuntimeError(saved.get("error") or "Could not update Flatpak profile")
                result = saved
                saved_config = dict(saved["config"])
                workarounds = self._stored_workarounds(app_id)
                # Assign the persisted native base FPS verbatim; WrapperService
                # validation (inside _apply_state) rejects out-of-range values
                # and the transaction rolls the saved config back untouched.
                workarounds["dxvkFrameRate"] = saved_config.get("recovery_base_fps", 0)
                self._apply_state(app_id, workarounds)
                # Report the persisted profile so the caller sees exactly what
                # landed on disk rather than the raw input.
                final = self.configuration_service.get_flatpak_config(app_id)
                if final.get("success") and final.get("exists"):
                    result = {**result, "config": final.get("config")}
            return result
        except Exception as error:
            return {
                "success": False,
                "message": "",
                "error": str(error),
                "app_id": str(app_id),
                "enabled": False,
            }

    def get_workaround_state(self, app_id: str) -> Dict[str, Any]:
        try:
            app_id = self.flatpak_service._validate_app_id(app_id)
            _, entry = self._state_entry(app_id)
            state = WrapperService._validate_state(
                entry.get("workaround_state", WrapperService.default_state())
            )
            return {
                "success": True,
                "message": "",
                "error": None,
                "app_id": app_id,
                "state": state,
            }
        except Exception as error:
            return {
                "success": False,
                "message": "",
                "error": str(error),
                "app_id": str(app_id),
                "state": None,
            }

    def set_workaround_state(self, app_id: str, workaround_state: Dict[str, Any]) -> Dict[str, Any]:
        try:
            app_id = self.flatpak_service._validate_app_id(app_id)
            state = self._apply_state(app_id, workaround_state)
            return {
                "success": True,
                "message": "",
                "error": None,
                "app_id": app_id,
                "state": state,
            }
        except Exception as error:
            return {
                "success": False,
                "message": "",
                "error": str(error),
                "app_id": str(app_id),
                "state": None,
            }

    def remove_app(self, app_id: str) -> Dict[str, Any]:
        try:
            app_id = self.flatpak_service._validate_app_id(app_id)
            with self._transaction(app_id):
                removed = self.flatpak_service.remove_app_override(app_id)
                if not removed.get("success"):
                    raise RuntimeError(removed.get("error") or "Could not remove Flatpak preparation")
                reset = self.configuration_service.reset_flatpak_config(app_id)
                if not reset.get("success"):
                    raise RuntimeError(reset.get("error") or "Could not remove Flatpak profile")
            return {
                "success": True,
                "message": "Flatpak profile removed",
                "error": None,
                "app_id": app_id,
                "enabled": False,
            }
        except Exception as error:
            return {
                "success": False,
                "message": "",
                "error": str(error),
                "app_id": str(app_id),
                "enabled": True,
            }

    def get_app(self, app_id: str) -> Dict[str, Any]:
        apps = self.get_apps()
        if not apps.get("success"):
            return {
                "success": False,
                "message": "",
                "error": apps.get("error"),
                "app_id": str(app_id),
                "enabled": False,
            }
        app = next((item for item in apps.get("apps", []) if item.get("app_id") == app_id), None)
        if app is None:
            return {
                "success": False,
                "message": "",
                "error": "Flatpak application is not installed",
                "app_id": str(app_id),
                "enabled": False,
            }
        return {"success": True, "message": "", "error": None, **app}

    def get_apps(self) -> Dict[str, Any]:
        try:
            result = self.flatpak_service.get_flatpak_apps()
            if not result.get("success"):
                raise RuntimeError(result.get("error") or "Could not list Flatpak applications")
            ownership = self.flatpak_service._read_state()
            apps = []
            for item in result.get("apps", []):
                app_id = item["app_id"]
                config_result = self.configuration_service.get_flatpak_config(app_id)
                if not config_result.get("success"):
                    raise RuntimeError(
                        config_result.get("error") or f"Could not read Flatpak profile for {app_id}"
                    )
                entry = ownership["prepared_apps"].get(app_id)
                workarounds = WrapperService.default_state()
                if isinstance(entry, dict):
                    workarounds = WrapperService._validate_state(
                        entry.get("workaround_state", workarounds)
                    )
                profile = self.configuration_service.flatpak_profile_name(app_id)
                selector_ready = False
                if item.get("prepared"):
                    shown = self.flatpak_service._run_flatpak_command(
                        ["override", "--user", "--show", app_id],
                        capture_output=True,
                        text=True,
                    )
                    selector_ready = (
                        shown.returncode == 0
                        and f"LSFGVK_PROFILE={profile}" in shown.stdout.splitlines()
                    )
                enrolled = bool(item.get("owned"))
                configured = bool(config_result.get("exists"))
                apps.append({
                    **item,
                    "profile": profile,
                    "configured": configured,
                    "enrolled": enrolled,
                    "enabled": bool(enrolled and configured and selector_ready),
                    "config": config_result.get("config"),
                    "workarounds": workarounds,
                })
            return {
                "success": True,
                "message": result.get("message", ""),
                "error": None,
                "apps": apps,
            }
        except Exception as error:
            return {"success": False, "message": "", "error": str(error), "apps": []}

    def get_running_apps(self) -> Dict[str, Any]:
        try:
            state = self.flatpak_service._read_state()
            enabled = set()
            for app_id, entry in state["prepared_apps"].items():
                if not isinstance(entry, dict):
                    continue
                config = self.configuration_service.get_flatpak_config(app_id)
                if not config.get("success"):
                    raise RuntimeError(
                        config.get("error") or f"Could not read Flatpak profile for {app_id}"
                    )
                if not config.get("exists"):
                    continue
                shown = self.flatpak_service._run_flatpak_command(
                    ["override", "--user", "--show", app_id],
                    capture_output=True,
                    text=True,
                )
                profile = self.configuration_service.flatpak_profile_name(app_id)
                if shown.returncode == 0 and self._environment_value(shown.stdout, "LSFGVK_PROFILE") == profile:
                    enabled.add(app_id)
            if not enabled:
                return {"success": True, "message": "", "error": None, "apps": []}
            result = self.flatpak_service._run_flatpak_command(
                ["ps", "--columns=application,active,pid"],
                capture_output=True,
                text=True,
            )
            if result.returncode != 0:
                raise OSError(result.stderr.strip() or "Could not inspect running Flatpak applications")
            running = []
            for line in result.stdout.splitlines():
                fields = line.split("\t") if "\t" in line else line.split()
                if not fields or fields[0] not in enabled:
                    continue
                active = len(fields) > 1 and fields[1].strip().lower() in {"1", "true", "yes", "active"}
                running.append({
                    "app_id": fields[0],
                    "active": active,
                    "pid": fields[2].strip() if len(fields) > 2 else "",
                    "start_time": self.flatpak_service._process_start_time(
                        fields[2].strip() if len(fields) > 2 else ""
                    ),
                })
            return {"success": True, "message": "", "error": None, "apps": running}
        except Exception as error:
            return {"success": False, "message": "", "error": str(error), "apps": []}
