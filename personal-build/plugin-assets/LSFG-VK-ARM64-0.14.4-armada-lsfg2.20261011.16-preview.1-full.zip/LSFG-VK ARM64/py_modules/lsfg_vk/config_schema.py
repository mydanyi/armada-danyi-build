"""Adapter for our ARM64 lsfg-vk v2 configuration format and legacy v1 import."""

import json
import tomllib
from pathlib import Path
from typing import Any, Dict, TypedDict

ConfigurationData = Dict[str, Any]


class ProfileData(TypedDict):
    profiles: Dict[str, Dict[str, Any]]
    global_config: Dict[str, Any]


class UnsupportedConfigurationVersion(ValueError):
    def __init__(self, version: Any):
        self.version = version
        super().__init__("unsupported lsfg-vk configuration version")


PROFILE_DEFAULTS: Dict[str, Any] = {
    "active_in": [],
    "pacing_mode": "vsync",
    "multiplier": 2,
    "generation_mode": "fixed",
    "target_fps": 60,
    "target_max_multiplier": 4,
    "adaptive_recovery": True,
    "recovery_base_fps": 0,
    "flow_scale": 0.8,
    "performance_mode": True,
    "override_present_mode": True,
    "preserve_swapchain_image_count": False,
}
GLOBAL_DEFAULTS: Dict[str, Any] = {"dll": "", "no_fp16": False}
OPTIONAL_GLOBAL_STRINGS = ("log_level", "log_file")


def _toml_value(value: Any) -> str:
    if isinstance(value, bool):
        return str(value).lower()
    if isinstance(value, str):
        return json.dumps(value)
    if isinstance(value, list):
        return "[ " + ", ".join(_toml_value(item) for item in value) + " ]"
    return str(value)


def _normalize_active_in(value: Any) -> list[str]:
    if value in (None, ""):
        return []
    if isinstance(value, str):
        return [value]
    if not isinstance(value, list):
        raise ValueError("active_in must be a string or list of strings")
    return [str(item) for item in value if str(item)]


def _bounded_int(config: Dict[str, Any], name: str, minimum: int, maximum: int) -> int:
    value = config.get(name, PROFILE_DEFAULTS[name])
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(f"{name} must be an integer")
    if not minimum <= value <= maximum:
        raise ValueError(f"{name} must be between {minimum} and {maximum}")
    return value


def _strict_bool(config: Dict[str, Any], name: str) -> bool:
    value = config.get(name, PROFILE_DEFAULTS[name])
    if type(value) is not bool:
        raise ValueError(f"{name} must be a boolean")
    return value


def _global_strings(raw: Dict[str, Any]) -> Dict[str, str]:
    values: Dict[str, str] = {}
    for name in OPTIONAL_GLOBAL_STRINGS:
        value = raw.get(name)
        if value not in (None, ""):
            values[name] = str(value)
    return values


class ConfigurationManager:
    @staticmethod
    def is_discardable_legacy_version(version: Any) -> bool:
        return version is None or version == "1" or (
            isinstance(version, (int, float))
            and not isinstance(version, bool)
            and version < 2
        )

    @staticmethod
    def get_defaults() -> Dict[str, Any]:
        return {**GLOBAL_DEFAULTS, **PROFILE_DEFAULTS}

    @staticmethod
    def validate_config(config: Dict[str, Any]) -> Dict[str, Any]:
        result = {**PROFILE_DEFAULTS, **GLOBAL_DEFAULTS}
        result.update({key: value for key, value in config.items() if key in result})
        result["active_in"] = _normalize_active_in(result["active_in"])
        result["pacing_mode"] = str(result["pacing_mode"]).lower()
        if result["pacing_mode"] != "vsync":
            raise ValueError("pacing_mode must be vsync")
        generation_mode = str(result["generation_mode"]).lower()
        if generation_mode not in ("fixed", "target"):
            raise ValueError("generation_mode must be fixed or target")
        result["generation_mode"] = generation_mode
        result["multiplier"] = _bounded_int(result, "multiplier", 1, 6)
        result["target_fps"] = _bounded_int(result, "target_fps", 30, 240)
        result["target_max_multiplier"] = _bounded_int(
            result, "target_max_multiplier", 2, 4
        )
        result["recovery_base_fps"] = _bounded_int(
            result, "recovery_base_fps", 0, 240
        )
        result["adaptive_recovery"] = _strict_bool(result, "adaptive_recovery")
        result["flow_scale"] = float(result["flow_scale"])
        if not 0.25 <= result["flow_scale"] <= 1.0:
            raise ValueError("flow_scale must be between 0.25 and 1.0")
        for name in (
            "no_fp16",
            "performance_mode",
            "override_present_mode",
            "preserve_swapchain_image_count",
        ):
            result[name] = bool(result[name])
        result["dll"] = str(result["dll"] or "")
        return result

    @staticmethod
    def generate_toml_content_multi_profile(profile_data: ProfileData) -> str:
        global_config = {**GLOBAL_DEFAULTS, **profile_data.get("global_config", {})}
        global_config.update(_global_strings(global_config))
        lines = ["version = 2", "", "[global]"]
        if global_config["dll"]:
            lines.append(f"dll = {_toml_value(global_config['dll'])}")
        lines.append(f"allow_fp16 = {_toml_value(not bool(global_config['no_fp16']))}")
        for name in OPTIONAL_GLOBAL_STRINGS:
            if global_config.get(name):
                lines.append(f"{name} = {_toml_value(global_config[name])}")
        profiles = sorted(profile_data["profiles"].items()) or [("", {})]
        for name, raw in profiles:
            config = ConfigurationManager.validate_config({**raw, **global_config})
            target_mode = config["generation_mode"] == "target"
            runtime_multiplier = (
                config["target_max_multiplier"] if target_mode else config["multiplier"]
            )
            runtime_target_fps = config["target_fps"] if target_mode else 0
            lines.extend(["", "[[profile]]", f"name = {_toml_value(name)}"])
            if config["active_in"]:
                lines.append(f"active_in = {_toml_value(config['active_in'])}")
            lines.extend([
                f"pacing_mode = {_toml_value(config['pacing_mode'])}",
                f"multiplier = {runtime_multiplier}",
                f"target_fps = {runtime_target_fps}",
                f"decky_fixed_multiplier = {config['multiplier']}",
                f"decky_target_fps = {config['target_fps']}",
                f"decky_target_max_multiplier = {config['target_max_multiplier']}",
                f"adaptive_recovery = {_toml_value(config['adaptive_recovery'])}",
                f"recovery_base_fps = {config['recovery_base_fps']}",
                f"flow_scale = {config['flow_scale']}",
                f"performance_mode = {_toml_value(config['performance_mode'])}",
                f"override_present_mode = {_toml_value(config['override_present_mode'])}",
                f"preserve_swapchain_image_count = {_toml_value(config['preserve_swapchain_image_count'])}",
            ])
        return "\n".join(lines) + "\n"

    @staticmethod
    def parse_toml_content_multi_profile(content: str) -> ProfileData:
        data = tomllib.loads(content)
        version = data.get("version")
        if version != 2:
            raise UnsupportedConfigurationVersion(version)
        raw_global = data.get("global", {})
        global_config: Dict[str, Any] = {
            "dll": str(raw_global.get("dll", "") or ""),
            "no_fp16": not bool(raw_global.get("allow_fp16", True)),
        }
        global_config.update(_global_strings(raw_global))
        profiles: Dict[str, Dict[str, Any]] = {}
        for profile in data.get("profile", []):
            name = str(profile.get("name", ""))
            config = ConfigurationManager._profile_from_runtime(
                profile, global_config
            )
            if name or config["active_in"]:
                profiles[name] = config
        return {"profiles": profiles, "global_config": global_config}

    @staticmethod
    def _profile_from_runtime(
        profile: Dict[str, Any], global_config: Dict[str, Any]
    ) -> Dict[str, Any]:
        runtime_multiplier = profile.get("multiplier", 2)
        runtime_target_fps = profile.get("target_fps", 0)
        if runtime_target_fps in (None, ""):
            runtime_target_fps = 0
        if isinstance(runtime_multiplier, bool) or not isinstance(runtime_multiplier, int):
            raise ValueError("multiplier must be an integer")
        if isinstance(runtime_target_fps, bool) or not isinstance(runtime_target_fps, int):
            raise ValueError("target_fps must be an integer")
        target_mode = runtime_target_fps > 0
        if target_mode:
            public_multiplier = profile.get(
                "decky_fixed_multiplier", runtime_multiplier
            )
            public_target_fps = runtime_target_fps
            target_max_multiplier = runtime_multiplier
        else:
            public_multiplier = profile.get(
                "decky_fixed_multiplier", runtime_multiplier
            )
            runtime_target_fps = profile.get("decky_target_fps", 60)
            target_max_multiplier = profile.get("decky_target_max_multiplier", 4)
        return ConfigurationManager.validate_config({
            **profile,
            **global_config,
            "generation_mode": "target" if target_mode else "fixed",
            "multiplier": public_multiplier,
            "target_fps": runtime_target_fps,
            "target_max_multiplier": target_max_multiplier,
        })

    @staticmethod
    def parse_toml_content_legacy(content: str) -> ProfileData:
        """Import our old version 1 conf.toml without touching its source file."""
        data = tomllib.loads(content)
        if data.get("version") not in (None, 1):
            raise ValueError("unsupported legacy lsfg-vk configuration version")
        raw_global = data.get("global", {})
        if "allow_fp16" in raw_global:
            no_fp16 = not bool(raw_global["allow_fp16"])
        else:
            no_fp16 = bool(raw_global.get("no_fp16", False))
        global_config: Dict[str, Any] = {
            "dll": str(raw_global.get("dll", "") or ""),
            "no_fp16": no_fp16,
        }
        profiles: Dict[str, Dict[str, Any]] = {}
        for game in data.get("game", []):
            exe = str(game.get("exe", "") or "").strip()
            if not exe:
                raise ValueError("legacy game entry is missing its exe name")
            dxvk_frame_rate = game.get("dxvk_frame_rate", 0)
            if dxvk_frame_rate in (None, ""):
                dxvk_frame_rate = 0
            if isinstance(dxvk_frame_rate, bool) or not isinstance(dxvk_frame_rate, int):
                raise ValueError("dxvk_frame_rate must be an integer")
            config = ConfigurationManager.validate_config({
                **game,
                **global_config,
                "recovery_base_fps": dxvk_frame_rate,
            })
            profiles[exe] = config
        return {"profiles": profiles, "global_config": global_config}
