import re
import tomllib
from typing import Any, Dict

from .base_service import BaseService
from .config_schema import ConfigurationManager, ProfileData, UnsupportedConfigurationVersion
from .runtime_service import RuntimeService
from .wrapper_service import WrapperService


class ConfigurationService(BaseService):
    FLATPAK_PROFILE_PREFIX = "flatpak:"
    LEGACY_TEMPLATE_FILENAME = "conf.toml"

    def __init__(self, logger=None, runtime_service: RuntimeService = None):
        super().__init__(logger)
        self.runtime_service = runtime_service or RuntimeService(logger=self.log)

    def _default_data(self) -> ProfileData:
        return {"profiles": {}, "global_config": {"dll": "", "no_fp16": False}}

    def _get_profile_data(self) -> ProfileData:
        if not self.config_file_path.exists():
            return self._default_data()
        content = self.config_file_path.read_text(encoding="utf-8")
        return ConfigurationManager.parse_toml_content_multi_profile(content)

    def _save_profile_data(self, data: ProfileData) -> None:
        content = ConfigurationManager.generate_toml_content_multi_profile(data)
        self.runtime_service.validate_config_content(content)
        self._write_file(self.config_file_path, content, 0o644)

    @staticmethod
    def _profile_for_appid(data: ProfileData, appid: str):
        value = str(appid)
        return next(
            (
                (name, profile)
                for name, profile in data["profiles"].items()
                if value in [str(selector) for selector in profile.get("active_in", [])]
            ),
            (None, None),
        )

    @staticmethod
    def _profile_available(data: ProfileData, name: str, appid: str) -> bool:
        """A name is free, or occupied only by this app as its sole selector.

        Sharing a profile with other App IDs never counts as exclusive ownership,
        so a shared profile can never be silently clobbered by a new App ID.
        """
        existing = data["profiles"].get(name)
        if existing is None:
            return True
        return [str(selector) for selector in existing.get("active_in", [])] == [str(appid)]

    @classmethod
    def _profile_name(cls, data: ProfileData, appid: str, game_name: str) -> str:
        name = str(game_name).strip()
        if not name:
            raise ValueError("game name is required")
        if cls._profile_available(data, name, appid):
            return name
        fallback = f"{name} ({appid})"
        if cls._profile_available(data, fallback, appid):
            return fallback
        suffix = 2
        while True:
            candidate = f"{fallback} ({suffix})"
            if cls._profile_available(data, candidate, appid):
                return candidate
            suffix += 1

    @classmethod
    def flatpak_profile_name(cls, app_id: str) -> str:
        value = str(app_id).strip()
        if not value:
            raise ValueError("Flatpak application ID is required")
        return f"{cls.FLATPAK_PROFILE_PREFIX}{value}"

    @staticmethod
    def _public_config(config: Dict[str, Any]) -> Dict[str, Any]:
        return ConfigurationManager.validate_config(config)

    def _read_legacy_template(self) -> Dict[str, Any]:
        path = self.config_dir / self.LEGACY_TEMPLATE_FILENAME
        try:
            if path.is_symlink() or not path.is_file():
                return {}
            content = path.read_text(encoding="utf-8")
        except OSError as error:
            self.log.error(f"Could not read legacy template {path}: {error}")
            return {}
        try:
            data = tomllib.loads(content)
        except Exception as error:
            self.log.error(f"Could not parse legacy template {path}: {error}")
            return {}
        if data.get("version") not in (None, 1):
            self.log.error(f"Unsupported legacy template version in {path}")
            return {}
        return data

    def _legacy_default_config(self, legacy: Dict[str, Any], data: ProfileData) -> Dict[str, Any] | None:
        current_profile = legacy.get("global", {}).get("current_profile")
        if current_profile in (None, ""):
            return None
        wanted = str(current_profile).strip()
        for game in legacy.get("game", []):
            if not isinstance(game, dict):
                continue
            exe = str(game.get("exe", "") or "").strip()
            if exe != wanted:
                continue
            dxvk_frame_rate = game.get("dxvk_frame_rate", 0)
            if dxvk_frame_rate in (None, ""):
                dxvk_frame_rate = 0
            if isinstance(dxvk_frame_rate, bool) or not isinstance(dxvk_frame_rate, int):
                raise ValueError("dxvk_frame_rate must be an integer")
            wrapper_defaults = WrapperService.default_state()
            config = ConfigurationManager.validate_config({
                **game,
                "recovery_base_fps": dxvk_frame_rate,
                **data["global_config"],
            })
            workarounds = {
                "dxvkFrameRate": dxvk_frame_rate if 0 <= dxvk_frame_rate <= 72 else wrapper_defaults["dxvkFrameRate"],
                "disableGamescopeWsi": not bool(game.get("enable_wsi", False)),
                "disableHdr": wrapper_defaults["disableHdr"],
                "disableSteamdeckMode": bool(game.get("disable_steamdeck_mode", wrapper_defaults["disableSteamdeckMode"])),
                "disableVkbasalt": bool(game.get("disable_vkbasalt", wrapper_defaults["disableVkbasalt"])),
                "enableZink": bool(game.get("enable_zink", wrapper_defaults["enableZink"])),
                "enableWow64": bool(game.get("enable_wow64", wrapper_defaults["enableWow64"])),
                "mangohudWorkaround": bool(game.get("mangohud_workaround", wrapper_defaults["mangohudWorkaround"])),
                "forceEnableVkbasalt": bool(game.get("force_enable_vkbasalt", wrapper_defaults["forceEnableVkbasalt"])),
            }
            return {"config": config, "workarounds": workarounds}
        return None

    def get_game_configs(self) -> Dict[str, Any]:
        try:
            data = self._get_profile_data()
            games = []
            seen_appids = set()
            for name, raw in data["profiles"].items():
                for selector in raw.get("active_in", []):
                    appid = str(selector)
                    if not re.fullmatch(r"-?[0-9]+", appid):
                        continue
                    if appid in seen_appids:
                        # First profile wins, matching _profile_for_appid so a
                        # duplicate selector can never be reported twice.
                        continue
                    seen_appids.add(appid)
                    games.append({"appid": appid, "profile": name, "config": self._public_config(raw)})
            response_kwargs: Dict[str, Any] = {"games": games}
            legacy = self._read_legacy_template()
            if legacy:
                try:
                    defaults = self._legacy_default_config(legacy, data)
                except Exception as error:
                    self.log.error(f"Omitting invalid legacy template defaults: {error}")
                    defaults = None
                if defaults is not None:
                    response_kwargs["default_config"] = defaults["config"]
                    response_kwargs["default_workarounds"] = defaults["workarounds"]
            return self._success_response(dict, global_config=dict(data["global_config"]), **response_kwargs)
        except Exception as error:
            self.log.error(f"Error reading game configs: {error}")
            return self._error_response(dict, str(error), games=[])

    def update_global_config(self, config: Dict[str, Any]) -> Dict[str, Any]:
        try:
            data = self._get_profile_data()
            merged_config = {**data["global_config"], **config}
            validated = self._public_config(merged_config)
            new_global = {
                "dll": validated["dll"],
                "no_fp16": validated["no_fp16"],
            }
            for name in ("log_level", "log_file"):
                existing = data["global_config"].get(name)
                if existing not in (None, ""):
                    new_global[name] = str(existing)
                elif merged_config.get(name) not in (None, ""):
                    new_global[name] = str(merged_config[name])
            data["global_config"] = new_global
            self._save_profile_data(data)
            return self._success_response(dict, global_config=dict(data["global_config"]))
        except Exception as error:
            return self._error_response(dict, str(error), global_config=None)

    def update_game_config(self, appid: str, game_name: str, config: Dict[str, Any]) -> Dict[str, Any]:
        try:
            data = self._get_profile_data()
            appid_str = str(appid)
            old_name, existing_profile = self._profile_for_appid(data, appid_str)
            name = self._profile_name(data, appid_str, game_name)
            base = dict(existing_profile) if existing_profile else {}
            base.update({key: value for key, value in config.items() if key != "no_fp16"})
            merged_config = {**data["global_config"], **base}
            if not base.get("dll"):
                merged_config["dll"] = data["global_config"].get("dll", "")
            validated = self._public_config(merged_config)
            validated["active_in"] = [appid_str]
            # Build the new profile map on a copy so the stored data is only
            # mutated once the new profile has been fully validated above.
            profiles = dict(data["profiles"])
            if old_name is not None:
                remaining = [
                    selector
                    for selector in existing_profile.get("active_in", [])
                    if str(selector) != appid_str
                ]
                if remaining:
                    # A shared profile keeps its name, all remaining selectors
                    # and every other field; only this App ID detaches.
                    old_copy = dict(existing_profile)
                    old_copy["active_in"] = remaining
                    profiles[old_name] = old_copy
                else:
                    # This App ID was the sole owner, so the profile is renamed.
                    profiles.pop(old_name, None)
            profiles[name] = validated
            data["profiles"] = profiles
            self._save_profile_data(data)
            return self._success_response(dict, appid=appid_str, config=validated)
        except Exception as error:
            return self._error_response(dict, str(error), appid=str(appid), config=None)

    def get_flatpak_config(self, app_id: str) -> Dict[str, Any]:
        try:
            data = self._get_profile_data()
            name = self.flatpak_profile_name(app_id)
            raw = data["profiles"].get(name)
            return self._success_response(
                dict,
                app_id=str(app_id),
                profile=name,
                exists=raw is not None,
                config=self._public_config(raw) if raw is not None else None,
                global_config=dict(data["global_config"]),
            )
        except Exception as error:
            return self._error_response(dict, str(error), app_id=str(app_id), config=None, exists=False)

    def update_flatpak_config(self, app_id: str, config: Dict[str, Any]) -> Dict[str, Any]:
        try:
            data = self._get_profile_data()
            name = self.flatpak_profile_name(app_id)
            base = dict(data["profiles"].get(name) or {})
            base.update({key: value for key, value in config.items() if key != "no_fp16"})
            merged_config = {**data["global_config"], **base}
            if not base.get("dll"):
                merged_config["dll"] = data["global_config"].get("dll", "")
            validated = self._public_config(merged_config)
            validated["active_in"] = []
            data["profiles"][name] = validated
            self._save_profile_data(data)
            return self._success_response(dict, app_id=str(app_id), profile=name, exists=True, config=validated)
        except Exception as error:
            return self._error_response(dict, str(error), app_id=str(app_id), config=None, exists=False)

    def reset_flatpak_config(self, app_id: str) -> Dict[str, Any]:
        try:
            data = self._get_profile_data()
            name = self.flatpak_profile_name(app_id)
            data["profiles"].pop(name, None)
            self._save_profile_data(data)
            return self._success_response(dict, app_id=str(app_id), profile=name, exists=False)
        except Exception as error:
            return self._error_response(dict, str(error), app_id=str(app_id), config=None, exists=False)

    def reset_all_flatpak_configs(self) -> Dict[str, Any]:
        try:
            data = self._get_profile_data()
            data["profiles"] = {
                name: profile
                for name, profile in data["profiles"].items()
                if not name.startswith(self.FLATPAK_PROFILE_PREFIX)
            }
            self._save_profile_data(data)
            return self._success_response(dict, global_config=dict(data["global_config"]))
        except Exception as error:
            return self._error_response(dict, str(error))

    def reset_game_config(self, appid: str) -> Dict[str, Any]:
        try:
            data = self._get_profile_data()
            appid_str = str(appid)
            data["profiles"] = self._strip_selectors(data["profiles"], {appid_str})
            self._save_profile_data(data)
            return self._success_response(dict, appid=appid_str, exists=False)
        except Exception as error:
            return self._error_response(dict, str(error), appid=str(appid), config=None)

    @staticmethod
    def _strip_selectors(profiles: Dict[str, Dict[str, Any]], requested: set) -> Dict[str, Dict[str, Any]]:
        """Drop the requested selectors from every profile.

        A profile only disappears when at least one of its selectors was removed
        and nothing remains; otherwise it keeps its name, its surviving selectors
        and every other field untouched.
        """
        result: Dict[str, Dict[str, Any]] = {}
        for name, profile in profiles.items():
            active = list(profile.get("active_in", []))
            remaining = [selector for selector in active if str(selector) not in requested]
            if len(remaining) == len(active):
                result[name] = profile
                continue
            if remaining:
                copy = dict(profile)
                copy["active_in"] = remaining
                result[name] = copy
        return result

    def reset_game_configs(self, appids: list[str]) -> Dict[str, Any]:
        try:
            if not isinstance(appids, list):
                raise ValueError("appids must be a list")
            requested = set()
            for appid in appids:
                if isinstance(appid, bool) or not isinstance(appid, (str, int)):
                    raise ValueError("appids must contain only strings or integers")
                value = str(appid)
                if not re.fullmatch(r"-?[0-9]+", value):
                    raise ValueError("appids must contain only numeric App IDs")
                requested.add(value)

            data = self._get_profile_data()
            data["profiles"] = self._strip_selectors(data["profiles"], requested)
            self._save_profile_data(data)
            return self._success_response(dict, global_config=dict(data["global_config"]), games=[])
        except Exception as error:
            return self._error_response(dict, str(error), games=[])

    def reset_all_game_configs(self) -> Dict[str, Any]:
        try:
            data = self._get_profile_data()
            profiles: Dict[str, Dict[str, Any]] = {}
            for name, profile in data["profiles"].items():
                active = list(profile.get("active_in", []))
                remaining = [
                    selector
                    for selector in active
                    if not re.fullmatch(r"-?[0-9]+", str(selector))
                ]
                if active and not remaining:
                    # Every selector was numeric, so the whole profile is a game
                    # profile and is removed.
                    continue
                if remaining != active:
                    copy = dict(profile)
                    copy["active_in"] = remaining
                    profiles[name] = copy
                else:
                    profiles[name] = profile
            data["profiles"] = profiles
            self._save_profile_data(data)
            return self._success_response(dict, global_config=dict(data["global_config"]), games=[])
        except Exception as error:
            return self._error_response(dict, str(error), games=[])
