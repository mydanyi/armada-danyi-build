from __future__ import annotations

import configparser
import hashlib
import json
import os
import pwd
import re
import shutil
import subprocess
import tempfile
import threading
from pathlib import Path
from typing import Dict, Optional, Set, Tuple

from .base_service import BaseService
from .constants import JSON_FILENAME, LIB_FILENAME
from .installation import InstallationService


class FlatpakService(BaseService):
    EXTENSION_ID = "org.freedesktop.Platform.VulkanLayer.lsfgvk_arm64"
    ARCH = "aarch64"
    EXTENSION_RELATIVE = Path(".local/share/flatpak/extension")
    SUPPORTED_RUNTIMES = ("24.08", "25.08")
    DERIVED_RUNTIME_IDS = {"org.gnome.Platform", "org.kde.Platform"}
    RUNTIME_METADATA_SECTION = "Extension org.freedesktop.Platform.GL"
    OWNERSHIP_FILENAME = "flatpak_state.json"
    OWNERSHIP_VERSION = 2
    MARKER_FILENAME = ".lsfg-arm64-owned.json"
    MARKER_VERSION = 1
    LAYER_NAME = "VK_LAYER_LSFGVK_ARM64_frame_generation"
    EXTENSION_LIBRARY_PATH = (
        "/usr/lib/extensions/vulkan/lsfgvk_arm64/lib/liblsfg-vk-arm64.so"
    )
    CORE_RELATIVE = f"lib/{LIB_FILENAME}"
    MANIFEST_RELATIVE = f"share/vulkan/implicit_layer.d/{JSON_FILENAME}"
    APP_ID_PATTERN = re.compile(
        r"^[A-Za-z0-9][A-Za-z0-9-]*(?:\.[A-Za-z0-9][A-Za-z0-9-]*)+$"
    )
    _SHA256_PATTERN = re.compile(r"^[0-9a-f]{64}$")

    # Environment variables we own for the Sandboxed runtime.
    ACTIVATION_ENV = "ENABLE_LSFGVK_ARM64"
    DISABLE_GUARD_ENV = "DISABLE_LSFGVK"
    # Original upstream Vulkan layer names that must stay suppressed so the
    # native x86 layer never loads inside the Flatpak sandbox.
    SUPPRESSED_LAYER_NAMES = (
        "VK_LAYER_LS_frame_generation",
        "VK_LAYER_LSFGVK_frame_generation",
    )
    # Keys whose values are ordered token lists that must be merged segment by
    # segment instead of being replaced wholesale.
    _LIST_SEPARATORS = {
        ("Context", "filesystems"): ";",
        ("Context", "unset-environment"): ";",
        ("Environment", "DXVK_CONFIG"): ";",
        ("Environment", "VK_LOADER_LAYERS_DISABLE"): ",",
    }

    def __init__(self, logger=None):
        super().__init__(logger)
        self.flatpak_command: Optional[str] = None
        self._lock = threading.RLock()

    @property
    def ownership_path(self) -> Path:
        return self.config_dir / self.OWNERSHIP_FILENAME

    @property
    def extension_root(self) -> Path:
        return self.user_home / self.EXTENSION_RELATIVE / self.EXTENSION_ID / self.ARCH

    @property
    def core_source_path(self) -> Path:
        return self.local_lib_dir / LIB_FILENAME

    def _clean_env(self) -> Dict[str, str]:
        env = os.environ.copy()
        env.pop("LD_LIBRARY_PATH", None)
        env["HOME"] = str(self.user_home)
        try:
            user_id = self.user_home.stat().st_uid
        except OSError:
            user_id = None
        if user_id is not None:
            env["XDG_RUNTIME_DIR"] = f"/run/user/{user_id}"
            env["DBUS_SESSION_BUS_ADDRESS"] = f"unix:path=/run/user/{user_id}/bus"
        path = [entry for entry in env.get("PATH", "").split(":") if entry]
        for entry in ("/usr/bin", "/usr/local/bin", "/bin"):
            if entry not in path:
                path.insert(0, entry)
        env["PATH"] = ":".join(path)
        return env

    def check_flatpak_available(self) -> bool:
        env = self._clean_env()
        self.flatpak_command = shutil.which("flatpak", path=env["PATH"])
        return self.flatpak_command is not None

    def _run_flatpak_command(self, args, **kwargs):
        if self.flatpak_command is None and not self.check_flatpak_available():
            raise FileNotFoundError("Flatpak command not available")
        env = self._clean_env()
        command = [self.flatpak_command, *args]
        try:
            user = pwd.getpwuid(self.user_home.stat().st_uid)
        except (KeyError, OSError) as error:
            raise RuntimeError(f"Unable to resolve Flatpak user for {self.user_home}") from error
        if os.geteuid() != user.pw_uid:
            runuser = shutil.which("runuser", path=env["PATH"])
            if runuser is None:
                raise FileNotFoundError("runuser command not available")
            command = [runuser, "--user", user.pw_name, "--", *command]
        kwargs.setdefault("timeout", 300 if args and args[0] in ("install", "uninstall") else 30)
        return subprocess.run(command, env=env, **kwargs)

    @classmethod
    def _validate_app_id(cls, app_id: str) -> str:
        if not isinstance(app_id, str) or cls.APP_ID_PATTERN.fullmatch(app_id) is None:
            raise ValueError("Invalid Flatpak application ID")
        return app_id

    @classmethod
    def _validate_runtime(cls, branch: str) -> str:
        if branch not in cls.SUPPORTED_RUNTIMES:
            raise ValueError(
                f"Unsupported Flatpak runtime branch {branch}; supported branches are "
                + ", ".join(cls.SUPPORTED_RUNTIMES)
            )
        return branch

    @classmethod
    def runtime_branch_from_metadata(cls, metadata: str) -> str:
        section = None
        versions = []
        for raw_line in metadata.splitlines() if isinstance(metadata, str) else []:
            line = raw_line.strip()
            if line.startswith("[") and line.endswith("]"):
                section = line[1:-1].strip()
                continue
            if section != cls.RUNTIME_METADATA_SECTION:
                continue
            key, separator, value = line.partition("=")
            if separator and key.strip() == "versions":
                versions.extend(part.strip() for part in value.split(";"))
        for value in versions:
            for branch in cls.SUPPORTED_RUNTIMES:
                if value == branch or value.startswith(f"{branch}-"):
                    return branch
        raise ValueError("Could not determine a supported Freedesktop base runtime from Flatpak metadata")

    @classmethod
    def _extension_ref(cls, branch: str) -> str:
        return f"{cls.EXTENSION_ID}/{cls.ARCH}/{cls._validate_runtime(branch)}"

    @staticmethod
    def _sha256_bytes(data: bytes) -> str:
        return hashlib.sha256(data).hexdigest()

    @staticmethod
    def _sha256_file(path: Path) -> str:
        digest = hashlib.sha256()
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(65536), b""):
                digest.update(chunk)
        return digest.hexdigest()

    def _branch_dir(self, branch: str) -> Path:
        return self.extension_root / self._validate_runtime(branch)

    def _core_path(self, branch: str) -> Path:
        return self._branch_dir(branch) / self.CORE_RELATIVE

    def _manifest_path(self, branch: str) -> Path:
        return self._branch_dir(branch) / self.MANIFEST_RELATIVE

    def _marker_path(self, branch: str) -> Path:
        return self._branch_dir(branch) / self.MARKER_FILENAME

    def _expected_manifest_content(self) -> str:
        manifest = {
            "file_format_version": "1.1.0",
            "layer": {
                "name": self.LAYER_NAME,
                "description": "Lossless Scaling frame generation layer (ARM64)",
                "implementation_version": "2",
                "library_path": self.EXTENSION_LIBRARY_PATH,
                "type": "GLOBAL",
                "api_version": "1.4.350",
                "enable_environment": {"ENABLE_LSFGVK_ARM64": "1"},
                "disable_environment": {"DISABLE_LSFGVK": "1"},
            },
        }
        return json.dumps(manifest, indent=2) + "\n"

    def _load_source_core(self) -> bytes:
        source = self.core_source_path
        if source.is_symlink() or not source.is_file():
            raise FileNotFoundError(f"ARM64 runtime library not found at {source}")
        data = source.read_bytes()
        InstallationService._validate_elf_arm64(str(source), data)
        return data

    def _write_bytes(self, path: Path, data: bytes, mode: int = 0o644) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary_path = None
        try:
            with tempfile.NamedTemporaryFile(
                mode="wb",
                dir=path.parent,
                prefix=f".{path.name}.",
                delete=False,
            ) as temporary_file:
                temporary_path = Path(temporary_file.name)
                temporary_file.write(data)
                temporary_file.flush()
                os.fsync(temporary_file.fileno())
            temporary_path.chmod(mode)
            os.replace(temporary_path, path)
        except Exception:
            if temporary_path is not None:
                temporary_path.unlink(missing_ok=True)
            raise

    def _owned_marker(self, branch: str) -> Optional[Dict[str, object]]:
        """Return the validated ownership marker, or None if none is present.

        A present-but-invalid marker fails closed so we never treat a foreign or
        corrupt directory as plugin-owned.
        """
        path = self._marker_path(branch)
        if not path.exists() and not path.is_symlink():
            return None
        if path.is_symlink() or not path.is_file():
            raise RuntimeError("Flatpak extension ownership marker is not a regular file")
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as error:
            raise RuntimeError(f"Could not read Flatpak extension ownership marker: {error}") from error
        if not isinstance(data, dict):
            raise RuntimeError("Invalid Flatpak extension ownership marker")
        if data.get("version") != self.MARKER_VERSION:
            raise RuntimeError("Unsupported Flatpak extension ownership marker version")
        if data.get("extension_id") != self.EXTENSION_ID or data.get("arch") != self.ARCH:
            raise RuntimeError("Flatpak extension ownership marker identity mismatch")
        if data.get("branch") != branch:
            raise RuntimeError("Flatpak extension ownership marker branch mismatch")
        files = data.get("files")
        if not isinstance(files, dict) or set(files) != {self.CORE_RELATIVE, self.MANIFEST_RELATIVE}:
            raise RuntimeError("Invalid Flatpak extension ownership marker file list")
        for digest in files.values():
            if not isinstance(digest, str) or self._SHA256_PATTERN.fullmatch(digest) is None:
                raise RuntimeError("Invalid Flatpak extension ownership marker hash")
        return data

    def _write_marker(self, branch: str, core_hash: str, manifest_hash: str) -> None:
        payload = {
            "version": self.MARKER_VERSION,
            "extension_id": self.EXTENSION_ID,
            "arch": self.ARCH,
            "branch": branch,
            "files": {
                self.CORE_RELATIVE: core_hash,
                self.MANIFEST_RELATIVE: manifest_hash,
            },
        }
        self._write_bytes(
            self._marker_path(branch),
            (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode("utf-8"),
            0o644,
        )

    def _branch_matches(self, branch: str, core_data: bytes, manifest_bytes: bytes) -> bool:
        core_path = self._core_path(branch)
        manifest_path = self._manifest_path(branch)
        if core_path.is_symlink() or not core_path.is_file():
            return False
        if manifest_path.is_symlink() or not manifest_path.is_file():
            return False
        try:
            return (
                self._sha256_file(core_path) == self._sha256_bytes(core_data)
                and self._sha256_file(manifest_path) == self._sha256_bytes(manifest_bytes)
            )
        except OSError:
            return False

    def _prune_empty_directories(self, branch: str) -> None:
        directory = self._branch_dir(branch)
        candidates = (
            directory / "lib",
            directory / "share/vulkan/implicit_layer.d",
            directory / "share/vulkan",
            directory / "share",
            directory,
            self.extension_root,
            self.extension_root.parent,
        )
        for candidate in candidates:
            try:
                if candidate.is_dir() and not candidate.is_symlink():
                    candidate.rmdir()
                    self.log.info(f"Removed empty directory {candidate}")
            except OSError:
                continue

    def _record_owned_branch(self, branch: str) -> None:
        state = self._read_state()
        owned = self._owned_branches(state)
        if branch not in owned:
            owned.add(branch)
            state["plugin_owned_branches"] = sorted(owned)
            self._write_state(state)

    def _installed_extension_branches(self, scope: Optional[str] = None) -> Set[str]:
        """Return branches holding the exact packaged ARM64 payload.

        A branch only counts as installed when its core matches the verified
        source core byte for byte and its manifest matches the expected content.
        A missing or invalid source core is an error: without a verified payload
        nothing can be reported as installed.
        """
        if scope not in (None, "user"):
            return set()
        core_data = self._load_source_core()
        manifest_bytes = self._expected_manifest_content().encode("utf-8")
        installed = set()
        for branch in self.SUPPORTED_RUNTIMES:
            directory = self._branch_dir(branch)
            if directory.is_symlink() or not directory.is_dir():
                continue
            if self._branch_matches(branch, core_data, manifest_bytes):
                installed.add(branch)
        return installed

    def _installed_branches_or_empty(self) -> Set[str]:
        try:
            return self._installed_extension_branches()
        except Exception:
            return set()

    def _user_extension_origin(self, branch: str) -> str:
        try:
            marker = self._owned_marker(branch)
        except RuntimeError:
            return ""
        return "lsfg-arm64" if marker is not None else ""

    def _empty_state(self) -> Dict[str, object]:
        return {
            "version": self.OWNERSHIP_VERSION,
            "plugin_owned_branches": [],
            "prepared_apps": {},
        }

    def _read_state(self) -> Dict[str, object]:
        if not self.ownership_path.exists():
            return self._empty_state()
        if self.ownership_path.is_symlink() or not self.ownership_path.is_file():
            raise RuntimeError("Flatpak ownership metadata is not a regular file")
        try:
            data = json.loads(self.ownership_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as error:
            raise RuntimeError(f"Could not read Flatpak ownership metadata: {error}") from error
        if data.get("version") != self.OWNERSHIP_VERSION:
            raise RuntimeError("Unsupported Flatpak ownership metadata version")
        branches = data.get("plugin_owned_branches")
        apps = data.get("prepared_apps")
        if not isinstance(branches, list) or not isinstance(apps, dict):
            raise RuntimeError("Invalid Flatpak ownership metadata")
        for branch in branches:
            self._validate_runtime(branch)
        for app_id, entry in apps.items():
            self._validate_app_id(app_id)
            if not isinstance(entry, dict):
                raise RuntimeError("Invalid Flatpak app ownership metadata")
        return data

    def _write_state(self, state: Dict[str, object]) -> None:
        branches = state.get("plugin_owned_branches", [])
        apps = state.get("prepared_apps", {})
        if not branches and not apps:
            self.ownership_path.unlink(missing_ok=True)
            return
        self._write_file(
            self.ownership_path,
            json.dumps(state, indent=2, sort_keys=True) + "\n",
        )

    def _owned_branches(self, state: Optional[Dict[str, object]] = None) -> Set[str]:
        current = state if state is not None else self._read_state()
        return {self._validate_runtime(branch) for branch in current["plugin_owned_branches"]}

    # ------------------------------------------------------------------
    # Flatpak override files (case-preserving ConfigParser, atomic writes)
    # ------------------------------------------------------------------

    def _override_path(self, app_id: str) -> Path:
        return self.user_home / ".local/share/flatpak/overrides" / self._validate_app_id(app_id)

    @staticmethod
    def _new_parser() -> configparser.ConfigParser:
        parser = configparser.ConfigParser(interpolation=None, delimiters=("=",), strict=True)
        parser.optionxform = str
        return parser

    def _parse_override(self, text: Optional[str]) -> configparser.ConfigParser:
        parser = self._new_parser()
        if text:
            parser.read_string(text)
        return parser

    @staticmethod
    def _serialize_override(parser: configparser.ConfigParser) -> str:
        blocks = []
        for section in parser.sections():
            items = list(parser.items(section))
            if not items:
                continue
            lines = [f"[{section}]"]
            lines.extend(f"{key}={value}" for key, value in items)
            blocks.append("\n".join(lines))
        if not blocks:
            return ""
        return "\n\n".join(blocks) + "\n"

    def _read_override_text(self, app_id: str) -> Optional[str]:
        path = self._override_path(app_id)
        if path.is_symlink() or (path.exists() and not path.is_file()):
            raise RuntimeError(f"Flatpak override path for {app_id} is not a regular file")
        if not path.exists():
            return None
        return path.read_text(encoding="utf-8")

    def _read_override_parser(self, app_id: str) -> configparser.ConfigParser:
        return self._parse_override(self._read_override_text(app_id))

    def _restore_override_text(self, app_id: str, text: Optional[str]) -> None:
        path = self._override_path(app_id)
        if text is None:
            path.unlink(missing_ok=True)
            return
        self._write_file(path, text)

    def _write_override_parser(self, app_id: str, parser: configparser.ConfigParser) -> None:
        path = self._override_path(app_id)
        content = self._serialize_override(parser)
        if not content:
            path.unlink(missing_ok=True)
            return
        self._write_file(path, content)

    @staticmethod
    def _parser_value(parser: configparser.ConfigParser, section: str, key: str) -> Optional[str]:
        if not parser.has_section(section):
            return None
        if key not in parser[section]:
            return None
        return parser[section][key]

    def _set_scalar(self, parser, section: str, key: str, value: Optional[str]) -> None:
        if value is None:
            if parser.has_section(section) and parser.has_option(section, key):
                parser.remove_option(section, key)
            return
        if not parser.has_section(section):
            parser.add_section(section)
        parser.set(section, key, value)

    @classmethod
    def _split_list_value(cls, value: Optional[str], separator: str) -> list:
        if value is None:
            return []
        return [token.strip() for token in value.split(separator) if token.strip()]

    @classmethod
    def _list_identity(cls, section: str, key: str, token: str) -> str:
        token = token.strip()
        if (section, key) == ("Context", "filesystems"):
            if token.startswith("!"):
                token = token[1:]
            for suffix in (":ro", ":rw"):
                if token.endswith(suffix):
                    token = token[: -len(suffix)]
                    break
            return token
        if (section, key) == ("Environment", "DXVK_CONFIG"):
            return token.split("=", 1)[0].strip()
        return token

    @classmethod
    def _list_value(cls, separator: str, tokens: list, fallback: Optional[str]) -> Optional[str]:
        if tokens:
            return separator.join(tokens)
        return "" if fallback is not None else None

    def _undo_list(
        self,
        section: str,
        key: str,
        separator: str,
        before: Optional[str],
        applied: Optional[str],
        current: Optional[str],
    ) -> list:
        """Virtually undo our previously owned delta from the current value.

        Tokens we added are removed only when they are still present verbatim;
        tokens we removed are re-added unless their semantic identity was
        overridden later by the user. When an added replacement for an identity
        is no longer present in the current value, the user deleted that
        replacement, so the pre-existing token for the same identity is not
        resurrected. Unrelated later additions and deletions are preserved.
        """
        current_tokens = self._split_list_value(current, separator)
        if before is None and applied is None:
            return current_tokens
        before_tokens = self._split_list_value(before, separator)
        applied_tokens = self._split_list_value(applied, separator)
        added = [token for token in applied_tokens if token not in before_tokens]
        removed = [token for token in before_tokens if token not in applied_tokens]
        result = [token for token in current_tokens if token not in added]
        identities = {self._list_identity(section, key, token) for token in result}
        added_identities = {self._list_identity(section, key, token) for token in added}
        for token in removed:
            identity = self._list_identity(section, key, token)
            if identity in identities:
                continue
            if identity in added_identities and not any(
                self._list_identity(section, key, added_token) == identity
                and added_token in current_tokens
                for added_token in added
            ):
                # Our replacement for this identity was removed by the user;
                # respect their deletion instead of restoring the old token.
                continue
            result.append(token)
            identities.add(identity)
        return result

    def _set_list(self, parser, section: str, key: str, separator: str, tokens: list, before: Optional[str]) -> None:
        if tokens:
            self._set_scalar(parser, section, key, separator.join(tokens))
        elif before is None:
            self._set_scalar(parser, section, key, None)
        else:
            self._set_scalar(parser, section, key, "")

    def _apply_field(self, parser, changes: dict, section: str, key: str, desired: Optional[str]) -> None:
        record = self._change_record(changes, section, key)
        before = record.get("before") if record else None
        applied = record.get("applied") if record else None
        current = self._parser_value(parser, section, key)
        separator = self._LIST_SEPARATORS.get((section, key))
        if separator is not None:
            if desired is None:
                # A list without a record was never touched by us; leave the
                # user's value alone rather than rewriting it.
                if record is None:
                    return
                tokens = self._undo_list(section, key, separator, before, applied, current)
                self._set_list(parser, section, key, separator, list(tokens), before)
                self._pop_change(changes, section, key)
                return
            # The pre-existing base is the current value with only our previous
            # contribution undone; with no record it is the current value, so a
            # pre-existing empty value is restored as empty instead of dropped.
            base = before if record is not None else current
            base_tokens = self._undo_list(section, key, separator, base, applied, current)
            desired_tokens = self._split_list_value(desired, separator)
            # An explicit desired list is written verbatim; an explicitly empty
            # list stays an empty value rather than being removed.
            self._set_scalar(parser, section, key, separator.join(desired_tokens))
            base_value = self._list_value(separator, base_tokens, base)
            applied_value = self._parser_value(parser, section, key)
            if applied_value == base_value:
                self._pop_change(changes, section, key)
            else:
                self._set_change(changes, section, key, base_value, applied_value)
            return
        if record is None:
            # No prior record: the pre-existing value must be restored verbatim.
            base = current
        elif current == applied:
            base = before
        else:
            # The user changed this scalar since we applied it; keep their edit
            # as the new base instead of clobbering it on restore.
            base = current
        self._set_scalar(parser, section, key, desired)
        if desired is None and base is None:
            self._pop_change(changes, section, key)
        elif desired is not None and desired == base:
            self._pop_change(changes, section, key)
        else:
            self._set_change(changes, section, key, base, desired)

    @staticmethod
    def _changes_for(state: Dict[str, object], app_id: str, create: bool = False) -> Optional[dict]:
        """Return the JSON-safe ``{section: {key: {before, applied}}}`` map."""
        apps = state["prepared_apps"]
        entry = apps.get(app_id)
        if not isinstance(entry, dict):
            if not create:
                return None
            entry = {}
            apps[app_id] = entry
        changes = entry.get("override_changes")
        if not isinstance(changes, dict):
            changes = {}
            entry["override_changes"] = changes
        return changes

    @staticmethod
    def _change_record(changes: Optional[dict], section: str, key: str) -> Optional[dict]:
        if not isinstance(changes, dict):
            return None
        section_changes = changes.get(section)
        if not isinstance(section_changes, dict):
            return None
        record = section_changes.get(key)
        return record if isinstance(record, dict) else None

    @staticmethod
    def _set_change(changes: dict, section: str, key: str, before: Optional[str], applied: Optional[str]) -> None:
        changes.setdefault(section, {})[key] = {"before": before, "applied": applied}

    @staticmethod
    def _pop_change(changes: dict, section: str, key: str) -> None:
        section_changes = changes.get(section)
        if not isinstance(section_changes, dict):
            return
        section_changes.pop(key, None)
        if not section_changes:
            changes.pop(section, None)

    def _apply_owned_overrides(self, app_id: str, values: Dict[str, Dict[str, Optional[str]]]) -> None:
        """Apply only the provided override fields and track ownership.

        The override file and ownership state are committed transactionally: if
        the state write fails after the file was written, the previous override
        file is restored and the error is re-raised so success is never claimed.
        """
        app_id = self._validate_app_id(app_id)
        with self._lock:
            previous_text = self._read_override_text(app_id)
            state = self._read_state()
            changes = self._changes_for(state, app_id, create=True)
            parser = self._parse_override(previous_text or "")
            for section, fields in values.items():
                if not isinstance(fields, dict):
                    raise RuntimeError("Flatpak override values must map keys to strings")
                for key, desired in fields.items():
                    self._apply_field(parser, changes, section, key, desired)
            entry = state["prepared_apps"][app_id]
            if not changes:
                entry.pop("override_changes", None)
            self._write_override_parser(app_id, parser)
            try:
                self._write_state(state)
            except Exception:
                self._restore_override_text(app_id, previous_text)
                raise

    def _restore_field(self, parser, section: str, key: str, before: Optional[str], applied: Optional[str]) -> None:
        current = self._parser_value(parser, section, key)
        separator = self._LIST_SEPARATORS.get((section, key))
        if separator is not None:
            tokens = self._undo_list(section, key, separator, before, applied, current)
            self._set_list(parser, section, key, separator, tokens, before)
            return
        if current == applied:
            self._set_scalar(parser, section, key, before)

    def _restore_owned_overrides(self, app_id: str, fields=None) -> None:
        """Restore all or the listed (section, key) fields and drop their records."""
        app_id = self._validate_app_id(app_id)
        targets_filter = None
        if fields is not None:
            targets_filter = {(section, key) for section, key in fields}
        with self._lock:
            previous_text = self._read_override_text(app_id)
            state = self._read_state()
            entry = state["prepared_apps"].get(app_id)
            changes = entry.get("override_changes") if isinstance(entry, dict) else None
            if not isinstance(changes, dict):
                return
            targets = [
                (section, key, record)
                for section, section_changes in changes.items()
                if isinstance(section_changes, dict)
                for key, record in section_changes.items()
                if isinstance(record, dict)
                and (targets_filter is None or (section, key) in targets_filter)
            ]
            parser = self._parse_override(previous_text or "")
            for section, key, record in targets:
                self._restore_field(
                    parser,
                    section,
                    key,
                    record.get("before"),
                    record.get("applied"),
                )
                self._pop_change(changes, section, key)
            if not changes:
                entry.pop("override_changes", None)
            self._write_override_parser(app_id, parser)
            try:
                self._write_state(state)
            except Exception:
                self._restore_override_text(app_id, previous_text)
                raise

    def _base_override_value(self, app_id: str, section: str, key: str) -> Optional[str]:
        """Return the value with only our owned contribution virtually undone."""
        app_id = self._validate_app_id(app_id)
        with self._lock:
            parser = self._read_override_parser(app_id)
            current = self._parser_value(parser, section, key)
            state = self._read_state()
            entry = state["prepared_apps"].get(app_id)
            changes = entry.get("override_changes") if isinstance(entry, dict) else None
            record = self._change_record(changes, section, key)
            if not isinstance(record, dict):
                return current
            before = record.get("before")
            applied = record.get("applied")
            separator = self._LIST_SEPARATORS.get((section, key))
            if separator is not None:
                tokens = self._undo_list(section, key, separator, before, applied, current)
                return self._list_value(separator, tokens, before)
            if current == applied:
                return before
            return current

    # ------------------------------------------------------------------
    # Process / runtime helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _parse_process_start_time(stat_content: str) -> Optional[int]:
        closing_command = stat_content.rfind(")")
        if closing_command < 0:
            return None
        fields = stat_content[closing_command + 2:].split()
        if len(fields) <= 19:
            return None
        try:
            return int(fields[19])
        except (TypeError, ValueError):
            return None

    @classmethod
    def _process_start_time(cls, pid: str) -> Optional[int]:
        if not isinstance(pid, str) or re.fullmatch(r"[0-9]+", pid) is None:
            return None
        try:
            stat_content = (Path("/proc") / pid / "stat").read_text(encoding="utf-8")
        except OSError:
            return None
        return cls._parse_process_start_time(stat_content)

    def _resolve_runtime(self, app_id: str) -> Tuple[str, str]:
        self._validate_app_id(app_id)
        if not self.check_flatpak_available():
            raise FileNotFoundError("Flatpak is not available on this system")
        result = self._run_flatpak_command(
            ["info", "--show-runtime", app_id],
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            raise OSError(result.stderr.strip() or f"Could not inspect Flatpak app {app_id}")
        runtime = result.stdout.strip().splitlines()[0] if result.stdout.strip() else ""
        parts = runtime.split("/")
        if len(parts) != 3:
            raise ValueError(f"Unsupported Flatpak runtime reference: {runtime}")
        if parts[1] != self.ARCH:
            raise ValueError(f"Unsupported Flatpak runtime architecture: {runtime}")
        if parts[0] == "org.freedesktop.Platform":
            return runtime, self._validate_runtime(parts[2])
        if parts[0] not in self.DERIVED_RUNTIME_IDS:
            raise ValueError(f"Unsupported Flatpak runtime reference: {runtime}")
        metadata_result = self._run_flatpak_command(
            ["info", "--show-metadata", runtime],
            capture_output=True,
            text=True,
        )
        if metadata_result.returncode != 0:
            raise OSError(metadata_result.stderr.strip() or f"Could not inspect Flatpak runtime {runtime}")
        return runtime, self.runtime_branch_from_metadata(metadata_result.stdout)

    def _dll_directory(self) -> Path:
        if self.config_file_path.exists():
            try:
                content = self.config_file_path.read_text(encoding="utf-8")
                match = re.search(
                    r'(?m)^[ \t]*dll[ \t]*=[ \t]*"((?:\\.|[^"\\])*)"',
                    content,
                )
                if match:
                    configured_dll = json.loads('"' + match.group(1) + '"')
                    if configured_dll:
                        return Path(configured_dll).parent
            except Exception:
                pass
        return self.user_home / ".local/share/Steam/steamapps/common/Lossless Scaling"

    def _filesystem_present(self, entries: Optional[str], host_path: Path) -> bool:
        accepted = {str(host_path)}
        try:
            accepted.add(f"~/{host_path.relative_to(self.user_home).as_posix()}")
        except ValueError:
            pass
        enabled = False
        for raw in (entries or "").split(";"):
            value = raw.strip()
            if not value:
                continue
            denied = value.startswith("!")
            path = value[1:] if denied else value
            path = path.split(":", 1)[0]
            if path in accepted:
                if denied:
                    return False
                enabled = True
        return enabled

    def _app_override_status(self, app_id: str) -> Dict[str, object]:
        app_id = self._validate_app_id(app_id)
        parser = self._read_override_parser(app_id)
        filesystems = self._parser_value(parser, "Context", "filesystems") or ""
        unset_environment = set(
            self._split_list_value(self._parser_value(parser, "Context", "unset-environment"), ";")
        )
        environment = {}
        if parser.has_section("Environment"):
            environment = {key: value for key, value in parser.items("Environment")}
        config_ready = self._filesystem_present(filesystems, self.config_dir)
        dll_ready = self._filesystem_present(filesystems, self._dll_directory())
        env_ready = (
            environment.get("LSFGVK_CONFIG") == str(self.config_file_path)
            and environment.get("LSFGVK_FLATPAK") == "1"
            and environment.get("LSFGVK_PROFILE") == f"flatpak:{app_id}"
            and self.DISABLE_GUARD_ENV in unset_environment
        )
        return {
            "filesystem_ready": config_ready and dll_ready,
            "environment_ready": env_ready,
            "prepared": config_ready and dll_ready and env_ready,
        }

    def get_extension_status(self):
        try:
            available = self.check_flatpak_available()
            installed = self._installed_extension_branches() if available else set()
            return self._success_response(
                dict,
                "Flatpak runtime extension status retrieved" if available else "Flatpak is not available",
                available=available,
                extension_id=self.EXTENSION_ID,
                supported_branches=list(self.SUPPORTED_RUNTIMES),
                installed_branches=sorted(installed),
            )
        except Exception as error:
            return self._error_response(
                dict,
                str(error),
                available=False,
                extension_id=self.EXTENSION_ID,
                supported_branches=list(self.SUPPORTED_RUNTIMES),
                installed_branches=[],
            )

    get_flatpak_support_status = get_extension_status

    def install_extension(self, branch: str):
        try:
            branch = self._validate_runtime(branch)
            if not self.check_flatpak_available():
                raise FileNotFoundError("Flatpak is not available on this system")
            with self._lock:
                core_data = self._load_source_core()
                manifest_bytes = self._expected_manifest_content().encode("utf-8")
                directory = self._branch_dir(branch)
                if directory.is_symlink() or (directory.exists() and not directory.is_dir()):
                    raise RuntimeError(f"Refusing to replace non-directory extension path {directory}")
                marker = self._owned_marker(branch)
                if marker is not None:
                    if self._branch_matches(branch, core_data, manifest_bytes):
                        # A valid marker with matching files means a previous run
                        # crashed before the ownership state was recorded; retry
                        # the state write instead of reinstalling.
                        self._record_owned_branch(branch)
                        return self._extension_result(branch, True, False, "is ready")
                elif directory.exists():
                    # An extension this plugin does not own is only usable when
                    # it already matches our payload exactly; never overwrite it.
                    if self._branch_matches(branch, core_data, manifest_bytes):
                        return self._extension_result(branch, True, False, "is ready")
                    raise RuntimeError(
                        f"Refusing to overwrite unowned Flatpak extension {self._extension_ref(branch)}"
                    )
                # Write the intent-ownership marker before the first payload byte
                # so an interrupted copy can be retried and completed later.
                self._write_marker(
                    branch,
                    self._sha256_bytes(core_data),
                    self._sha256_bytes(manifest_bytes),
                )
                self._write_bytes(self._core_path(branch), core_data, 0o644)
                self._write_bytes(self._manifest_path(branch), manifest_bytes, 0o644)
                self._record_owned_branch(branch)
                return self._extension_result(branch, True, False, "installed")
        except Exception as error:
            return self._error_response(dict, str(error), runtime_branch=branch, installed=False, enabled=False)

    def _remove_extension(self, branch: str) -> bool:
        directory = self._branch_dir(branch)
        if not directory.exists():
            return False
        if directory.is_symlink() or not directory.is_dir():
            raise RuntimeError(f"Refusing to remove non-directory extension path {directory}")
        if self._owned_marker(branch) is None:
            # Not plugin-owned; preserve it untouched.
            return False
        removed = False
        for relative in (self.CORE_RELATIVE, self.MANIFEST_RELATIVE, self.MARKER_FILENAME):
            path = directory / relative
            if path.is_symlink():
                path.unlink()
                removed = True
            elif path.is_file():
                path.unlink()
                removed = True
        self._prune_empty_directories(branch)
        return removed

    def _extension_result(self, branch: str, installed: bool, removed: bool, verb: str):
        return self._success_response(
            dict,
            f"lsfg-vk {branch} runtime extension {verb}",
            runtime_branch=branch,
            installed=installed,
            enabled=installed,
            removed=removed,
        )

    def uninstall_extension(self, branch: str):
        try:
            branch = self._validate_runtime(branch)
            if not self.check_flatpak_available():
                raise FileNotFoundError("Flatpak is not available on this system")
            with self._lock:
                state = self._read_state()
                owned = self._owned_branches(state)
                marker = self._owned_marker(branch)
                if branch not in owned and marker is None:
                    installed = branch in self._installed_branches_or_empty()
                    return self._extension_result(branch, installed, False, "preserved (not plugin-owned)")
                removed = self._remove_extension(branch)
                owned.discard(branch)
                state["plugin_owned_branches"] = sorted(owned)
                self._write_state(state)
                installed = branch in self._installed_branches_or_empty()
                return self._extension_result(branch, installed, removed, "uninstalled")
        except Exception as error:
            return self._error_response(dict, str(error), runtime_branch=branch, removed=False, installed=False, enabled=False)

    def ensure_extension(self, branch: str):
        return self.install_extension(branch)

    def set_extension_enabled(self, branch: str, enabled: bool):
        if type(enabled) is not bool:
            return self._error_response(dict, "enabled must be a boolean", runtime_branch=branch, installed=False, enabled=False)
        return self.install_extension(branch) if enabled else self.uninstall_extension(branch)

    def get_flatpak_apps(self):
        try:
            if not self.check_flatpak_available():
                raise FileNotFoundError("Flatpak is not available on this system")
            installed_extensions = self._installed_branches_or_empty()
            state = self._read_state()
            owned_apps = state["prepared_apps"]
            result = self._run_flatpak_command(
                ["list", "--app", "--columns=name,application"],
                capture_output=True,
                text=True,
                check=True,
            )
            apps = []
            for line in result.stdout.splitlines():
                fields = line.split("\t")
                if len(fields) < 2:
                    continue
                name, app_id = fields[0].strip(), fields[1].strip()
                if not app_id:
                    continue
                item = {
                    "app_id": app_id,
                    "app_name": name or app_id,
                    "runtime": None,
                    "runtime_branch": None,
                    "runtime_ready": False,
                    "prepared": False,
                    "owned": app_id in owned_apps,
                    "error": None,
                }
                try:
                    runtime, branch = self._resolve_runtime(app_id)
                    status = self._app_override_status(app_id)
                    item.update({
                        "runtime": runtime,
                        "runtime_branch": branch,
                        "runtime_ready": branch in installed_extensions,
                        "prepared": status["prepared"],
                    })
                except Exception as error:
                    item["error"] = str(error)
                apps.append(item)
            apps.sort(key=lambda item: str(item["app_name"]).lower())
            return self._success_response(dict, f"Found {len(apps)} Flatpak applications", apps=apps)
        except Exception as error:
            return self._error_response(dict, str(error), apps=[])

    def _prepare_values(self, app_id: str) -> Dict[str, Dict[str, Optional[str]]]:
        config_dir = str(self.config_dir)
        dll_dir = str(self._dll_directory())
        filesystems = self._split_list_value(
            self._base_override_value(app_id, "Context", "filesystems"), ";"
        )
        for required in (f"{config_dir}:ro", f"{dll_dir}:ro"):
            identity = self._list_identity("Context", "filesystems", required)
            filesystems = [
                token
                for token in filesystems
                if self._list_identity("Context", "filesystems", token) != identity
            ]
            filesystems.append(required)
        unset_tokens = [
            token
            for token in self._split_list_value(
                self._base_override_value(app_id, "Context", "unset-environment"), ";"
            )
            if token != self.ACTIVATION_ENV
        ]
        if self.DISABLE_GUARD_ENV not in unset_tokens:
            unset_tokens.append(self.DISABLE_GUARD_ENV)
        layers = self._split_list_value(
            self._base_override_value(app_id, "Environment", "VK_LOADER_LAYERS_DISABLE"), ","
        )
        for name in self.SUPPRESSED_LAYER_NAMES:
            if name not in layers:
                layers.append(name)
        return {
            "Context": {
                "filesystems": ";".join(filesystems),
                "unset-environment": ";".join(unset_tokens),
            },
            "Environment": {
                self.DISABLE_GUARD_ENV: None,
                "LSFGVK_CONFIG": str(self.config_file_path),
                "LSFGVK_FLATPAK": "1",
                "LSFGVK_PROFILE": f"flatpak:{app_id}",
                self.ACTIVATION_ENV: "1",
                "VK_LOADER_LAYERS_DISABLE": ",".join(layers),
            },
        }

    def prepare_app(self, app_id: str):
        try:
            app_id = self._validate_app_id(app_id)
            with self._lock:
                runtime, branch = self._resolve_runtime(app_id)
                extension = self.ensure_extension(branch)
                if not extension.get("success") or not extension.get("installed"):
                    raise RuntimeError(extension.get("error") or f"Could not install Flatpak runtime {branch}")
                previous_text = self._read_override_text(app_id)
                previous_state = self._read_state()
                try:
                    self._apply_owned_overrides(app_id, self._prepare_values(app_id))
                    if not self._app_override_status(app_id)["prepared"]:
                        raise RuntimeError(f"Flatpak preparation did not become visible for {app_id}")
                except Exception:
                    # Roll back partial changes but never claim success.
                    try:
                        self._restore_override_text(app_id, previous_text)
                        self._write_state(previous_state)
                    except Exception:
                        pass
                    raise
                return self._success_response(
                    dict,
                    "Flatpak application prepared for lsfg-vk",
                    app_id=app_id,
                    runtime=runtime,
                    runtime_branch=branch,
                    prepared=True,
                    owned=True,
                )
        except Exception as error:
            return self._error_response(dict, str(error), app_id=app_id, prepared=False, owned=False)

    def remove_app_override(self, app_id: str):
        try:
            app_id = self._validate_app_id(app_id)
            with self._lock:
                state = self._read_state()
                apps = state["prepared_apps"]
                if app_id not in apps:
                    return self._success_response(
                        dict,
                        "Flatpak application is not plugin-owned; existing overrides were preserved",
                        app_id=app_id,
                        prepared=self._app_override_status(app_id)["prepared"],
                        owned=False,
                    )
                self._restore_owned_overrides(app_id)
                state = self._read_state()
                if app_id in state["prepared_apps"]:
                    state["prepared_apps"].pop(app_id, None)
                    self._write_state(state)
                return self._success_response(
                    dict,
                    "Plugin-owned Flatpak override restored",
                    app_id=app_id,
                    prepared=self._app_override_status(app_id)["prepared"],
                    owned=False,
                )
        except Exception as error:
            return self._error_response(dict, str(error), app_id=app_id, prepared=False, owned=True)

    def remove_plugin_owned_environment(self):
        try:
            with self._lock:
                state = self._read_state()
                failures = []
                removed_apps = []
                for app_id in list(state["prepared_apps"]):
                    result = self.remove_app_override(app_id)
                    if result.get("success"):
                        removed_apps.append(app_id)
                    else:
                        failures.append(f"{app_id}: {result.get('error')}")
                if failures:
                    return self._error_response(
                        dict,
                        "; ".join(failures),
                        removed_apps=removed_apps,
                        removed_branches=[],
                    )
                state = self._read_state()
                removed_branches = []
                for branch in sorted(self._owned_branches(state)):
                    result = self.uninstall_extension(branch)
                    if result.get("success"):
                        removed_branches.append(branch)
                    else:
                        failures.append(f"{branch}: {result.get('error')}")
                if failures:
                    return self._error_response(
                        dict,
                        "; ".join(failures),
                        removed_apps=removed_apps,
                        removed_branches=removed_branches,
                    )
                return self._success_response(
                    dict,
                    "Plugin-owned Flatpak state removed",
                    removed_apps=removed_apps,
                    removed_branches=removed_branches,
                )
        except Exception as error:
            return self._error_response(dict, str(error), removed_apps=[], removed_branches=[])
