import json
import os
import struct
import tarfile
import tempfile
import traceback
from pathlib import Path
from typing import Dict

from .base_service import BaseService
from .config_schema import ConfigurationManager, ProfileData, UnsupportedConfigurationVersion
from .constants import (
    ARCHIVE_FILENAME,
    BIN_DIR,
    CLI_FILENAME,
    JSON_FILENAME,
    LEGACY_JSON_FILENAME,
    LEGACY_LIB_FILENAME,
    LIB_FILENAME,
    LOCAL_SHARE,
    UI_DESKTOP_FILENAME,
    UI_FILENAME,
    UI_ICON_FILENAME,
)
from .runtime_service import RuntimeService
from .steam_service import SteamService
from .types import InstallationCheckResponse, InstallationResponse, UninstallationResponse


class InstallationService(BaseService):
    def __init__(
        self,
        logger=None,
        runtime_service: RuntimeService = None,
        steam_service: SteamService = None,
    ):
        super().__init__(logger)
        self.runtime_service = runtime_service or RuntimeService(logger=self.log)
        self.steam_service = steam_service or SteamService(logger=self.log)
        self.lib_file = self.local_lib_dir / LIB_FILENAME
        self.json_file = self.local_share_dir / JSON_FILENAME
        self.cli_file = self.local_bin_dir / CLI_FILENAME
        self.legacy_lib_file = self.local_lib_dir / LEGACY_LIB_FILENAME
        self.legacy_json_file = self.local_share_dir / LEGACY_JSON_FILENAME
        self._last_install_error: str | None = None

    @staticmethod
    def _archive_path() -> Path:
        return Path(__file__).parent.parent.parent / BIN_DIR / ARCHIVE_FILENAME

    def install(self) -> InstallationResponse:
        try:
            archive_path = self._archive_path()
            if not archive_path.exists():
                raise FileNotFoundError(f"{ARCHIVE_FILENAME} not found at {archive_path}")
            # Preflight the whole archive before any payload or configuration
            # write, so a malformed or mistargeted archive leaves the existing
            # installation (including migrated profiles) untouched.
            payloads = self._inspect_archive(archive_path)
            self._ensure_directories()
            profile_data = self._prepare_config()
            self._install_archive(payloads)
            content = ConfigurationManager.generate_toml_content_multi_profile(profile_data)
            self.runtime_service.validate_config_content(content)
            self._write_file(self.config_file_path, content, 0o644)
            self._remove_legacy_layer_files()
            self._last_install_error = None
            return self._success_response(InstallationResponse, "lsfg-vk 2.0.0 installed successfully")
        except Exception as error:
            self._last_install_error = str(error)
            self.log.error(f"Error installing lsfg-vk: {error}")
            return self._error_response(InstallationResponse, str(error))

    def ensure_installed(self) -> InstallationResponse:
        try:
            archive_path = self._archive_path()
            if not archive_path.exists():
                raise FileNotFoundError(f"{ARCHIVE_FILENAME} not found at {archive_path}")
            payloads = self._inspect_archive(archive_path)
            if self._payloads_current(payloads) and self._config_current():
                self._last_install_error = None
                return self._success_response(
                    InstallationResponse, "lsfg-vk 2.0.0 is already installed"
                )
            return self.install()
        except Exception as error:
            self._last_install_error = str(error)
            self.log.error(f"Error ensuring lsfg-vk installation: {error}")
            return self._error_response(InstallationResponse, str(error))

    def _payloads_current(self, payloads: Dict[str, bytes]) -> bool:
        manifest_source = f"share/vulkan/implicit_layer.d/{JSON_FILENAME}"
        for source_path, (destination, mode) in self._payload_destinations().items():
            if source_path == manifest_source:
                # The archived manifest carries a relative library path; the
                # installed one is compared against our own absolute manifest.
                expected = self._layer_manifest_content().encode("utf-8")
            else:
                expected = payloads[source_path]
            if not self._matches_file(destination, expected, mode):
                return False
        return True

    @staticmethod
    def _matches_file(destination: Path, expected: bytes, mode: int) -> bool:
        try:
            if destination.is_symlink() or not destination.is_file():
                return False
            if (destination.stat().st_mode & 0o777) != mode:
                return False
            return destination.read_bytes() == expected
        except OSError:
            return False

    def _config_current(self) -> bool:
        if self.config_file_path.is_symlink() or not self.config_file_path.is_file():
            return False
        try:
            ConfigurationManager.parse_toml_content_multi_profile(
                self.config_file_path.read_text(encoding="utf-8")
            )
        except Exception:
            return False
        return True

    def _payload_destinations(self) -> Dict[str, tuple[Path, int]]:
        return {
            f"bin/{CLI_FILENAME}": (self.cli_file, 0o755),
            f"bin/{UI_FILENAME}": (self.local_bin_dir / UI_FILENAME, 0o755),
            f"lib/{LIB_FILENAME}": (self.lib_file, 0o644),
            f"share/vulkan/implicit_layer.d/{JSON_FILENAME}": (self.json_file, 0o644),
            f"share/applications/{UI_DESKTOP_FILENAME}": (
                self.user_home / LOCAL_SHARE / "applications" / UI_DESKTOP_FILENAME,
                0o644,
            ),
            f"share/icons/hicolor/256x256/apps/{UI_ICON_FILENAME}": (
                self.user_home / LOCAL_SHARE / "icons/hicolor/256x256/apps" / UI_ICON_FILENAME,
                0o644,
            ),
        }

    @staticmethod
    def _validate_elf_arm64(name: str, data: bytes) -> None:
        if len(data) < 20 or data[:4] != b"\x7fELF":
            raise ValueError(f"{name} is not an ELF binary")
        if data[4] != 2 or data[5] != 1:
            raise ValueError(f"{name} is not a 64-bit little-endian ELF binary")
        machine = struct.unpack_from("<H", data, 18)[0]
        if machine != 183:
            raise ValueError(f"{name} is not an ARM64 ELF binary")

    def _inspect_archive(self, archive_path: Path) -> Dict[str, bytes]:
        payloads: Dict[str, bytes] = {}
        destinations = self._payload_destinations()
        with tarfile.open(archive_path, "r:*") as archive:
            members = {
                member.name.removeprefix("./"): member
                for member in archive.getmembers()
                if member.isfile()
            }
            missing = sorted(set(destinations) - set(members))
            if missing:
                raise OSError("Archive is missing required files: " + ", ".join(missing))
            binary_names = (f"bin/{CLI_FILENAME}", f"bin/{UI_FILENAME}", f"lib/{LIB_FILENAME}")
            for source_path in destinations:
                data = archive.extractfile(members[source_path]).read()
                if source_path in binary_names:
                    self._validate_elf_arm64(source_path, data)
                payloads[source_path] = data
        return payloads

    def _install_archive(self, payloads: Dict[str, bytes]) -> None:
        destinations = self._payload_destinations()
        for source_path, data in payloads.items():
            destination, mode = destinations[source_path]
            destination.parent.mkdir(parents=True, exist_ok=True)
            temporary_path = None
            try:
                with tempfile.NamedTemporaryFile(
                    mode="wb",
                    dir=destination.parent,
                    prefix=f".{destination.name}.",
                    delete=False,
                ) as temporary_file:
                    temporary_path = Path(temporary_file.name)
                    temporary_file.write(data)
                    temporary_file.flush()
                    os.fsync(temporary_file.fileno())
                temporary_path.chmod(mode)
                os.replace(temporary_path, destination)
            except Exception:
                if temporary_path is not None:
                    temporary_path.unlink(missing_ok=True)
                raise
        self._write_layer_manifest()

    def _layer_manifest_content(self) -> str:
        manifest = {
            "file_format_version": "1.1.0",
            "layer": {
                "name": "VK_LAYER_LSFGVK_ARM64_frame_generation",
                "description": "Lossless Scaling frame generation layer (ARM64)",
                "implementation_version": "2",
                "library_path": str(self.lib_file),
                "type": "GLOBAL",
                "api_version": "1.4.350",
                "enable_environment": {"ENABLE_LSFGVK_ARM64": "1"},
                "disable_environment": {"DISABLE_LSFGVK": "1"},
            },
        }
        return json.dumps(manifest, indent=2) + "\n"

    def _write_layer_manifest(self) -> None:
        self._write_file(
            self.json_file,
            self._layer_manifest_content(),
            0o644,
        )

    def _default_config(self) -> ProfileData:
        defaults = ConfigurationManager.get_defaults()
        return ProfileData(
            profiles={},
            global_config={"dll": defaults["dll"], "no_fp16": defaults["no_fp16"]},
        )

    def _prepare_config(self) -> ProfileData:
        if self.config_file_path.exists():
            profile_data = ConfigurationManager.parse_toml_content_multi_profile(
                self.config_file_path.read_text(encoding="utf-8")
            )
        else:
            profile_data = self._read_legacy_config() or self._default_config()
        self._resolve_dll_path(profile_data)
        return self._normalize_profiles(profile_data)

    def _read_legacy_config(self) -> ProfileData | None:
        legacy_path = self.config_dir / "conf.toml"
        if legacy_path.exists():
            return ConfigurationManager.parse_toml_content_legacy(
                legacy_path.read_text(encoding="utf-8")
            )
        runtime_path = self.config_dir / "decky-v2.toml"
        if runtime_path.exists():
            return ConfigurationManager.parse_toml_content_multi_profile(
                runtime_path.read_text(encoding="utf-8")
            )
        return None

    def _normalize_profiles(self, profile_data: ProfileData) -> ProfileData:
        defaults = ConfigurationManager.get_defaults()
        for name, profile in profile_data["profiles"].items():
            profile_data["profiles"][name] = ConfigurationManager.validate_config(
                {**defaults, **profile, **profile_data["global_config"]}
            )
        return profile_data

    def _resolve_dll_path(self, profile_data: ProfileData) -> bool:
        current_path = str(profile_data["global_config"].get("dll") or "")
        if current_path:
            current = Path(current_path)
            if current.name in ("Lossless.dll", "LosslessScaling.dll"):
                normalized = current.parent / "lsfg-vk.dll"
                profile_data["global_config"]["dll"] = str(normalized)
                current_path = str(normalized)
        if current_path and Path(current_path).is_file():
            return False
        dll_path = self.steam_service.find_lsfg_vk_dll()
        if dll_path and current_path != dll_path:
            profile_data["global_config"]["dll"] = dll_path
            return True
        return False

    def _repair_dll_path(self) -> None:
        if not self.config_file_path.is_file():
            return
        try:
            profile_data = ConfigurationManager.parse_toml_content_multi_profile(
                self.config_file_path.read_text(encoding="utf-8")
            )
            previous_dll = profile_data["global_config"].get("dll")
            self._resolve_dll_path(profile_data)
            current_dll = profile_data["global_config"].get("dll")
            if current_dll == previous_dll:
                return
            content = ConfigurationManager.generate_toml_content_multi_profile(profile_data)
            self.runtime_service.validate_config_content(content)
            self._write_file(self.config_file_path, content, 0o644)
            self.log.info(f"Repaired lsfg-vk DLL path: {current_dll}")
        except Exception as error:
            self.log.warning(f"Could not repair lsfg-vk DLL path: {error}")

    def _remove_legacy_layer_files(self) -> None:
        for path in (self.legacy_lib_file, self.legacy_json_file):
            self._remove_if_exists(path)

    _GENERATED_LAUNCHER_MARKER = (
        "# lsfg-vk launch script generated by LSFG-VK ARM64 plugin"
    )
    _PASSTHROUGH_MARKER = (
        "# lsfg-vk-arm64 safe passthrough retained for existing launch options."
    )

    def _is_owned_launcher(self, content: str) -> bool:
        lines = content.splitlines()
        if any(line.strip() == self._GENERATED_LAUNCHER_MARKER for line in lines[:8]):
            return True
        if any(line.strip() == self._PASSTHROUGH_MARKER for line in lines[:8]):
            return True
        if len(lines) >= 2 and lines[1].startswith("# Current profile: "):
            # Generated scripts may place caps/comments before the ARM64
            # activation lines, so scan the full content for these tokens.
            return (
                "ENABLE_LSFGVK_ARM64" in content
                and "lsfg-vk-arm64/decky-v2.toml" in content
                and "LSFGVK_PROFILE=decky-active" in content
            )
        return False

    def _leave_safe_passthrough(self) -> str | None:
        script_path = self.legacy_script_path
        if not script_path.exists() and not script_path.is_symlink():
            return None
        if script_path.is_symlink() or not script_path.is_file():
            return None
        try:
            content = script_path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            return None
        if not self._is_owned_launcher(content):
            return None
        self._write_file(
            script_path,
            "#!/bin/sh\n"
            "# lsfg-vk-arm64 safe passthrough retained for existing launch options.\n"
            'exec "$@"\n',
            0o755,
        )
        return str(script_path)

    def _prune_empty_directories(self) -> None:
        # Only prune directories created by this plugin.  Never remove a
        # non-empty directory because the user's other tools may use it.
        candidates = (
            self.config_dir,
            self.local_bin_dir,
            self.local_lib_dir,
            self.local_share_dir,
            self.user_home / LOCAL_SHARE / "applications",
            self.user_home / LOCAL_SHARE / "icons/hicolor/256x256/apps",
        )
        for directory in candidates:
            try:
                if directory.is_dir() and not directory.is_symlink():
                    directory.rmdir()
                    self.log.info(f"Removed empty directory {directory}")
            except OSError:
                continue

    def check_installation(self) -> InstallationCheckResponse:
        installed = False
        try:
            installed = all(
                path.is_file()
                for path in (
                    self.cli_file,
                    self.lib_file,
                    self.json_file,
                    self.config_file_path,
                )
            )
            if installed:
                self._repair_dll_path()
            lossless_scaling = self.runtime_service.check_lossless_scaling()
            return {
                "installed": installed,
                "lossless_scaling_installed": bool(lossless_scaling["installed"]),
                "lossless_scaling_status": str(lossless_scaling["status"]),
                "error": self._last_install_error,
            }
        except Exception as error:
            # A runtime probe failure must not erase an installation whose
            # payloads are already present on disk.
            return {
                "installed": installed,
                "lossless_scaling_installed": False,
                "lossless_scaling_status": str(error),
                "error": str(error),
            }

    def uninstall(self) -> UninstallationResponse:
        try:
            # Normalize an owned legacy launcher to a safe passthrough on every
            # uninstall, before removing runtime files. The retained passthrough
            # is intentionally not reported as a removed file.
            # Only the six owned runtime payloads are removed. The user's
            # configuration (conf-v2.toml) and legacy profiles are preserved.
            self._leave_safe_passthrough()
            removed = [
                str(path)
                for path in (
                    self.lib_file,
                    self.json_file,
                    self.cli_file,
                    self.local_bin_dir / UI_FILENAME,
                    self.user_home / LOCAL_SHARE / "applications" / UI_DESKTOP_FILENAME,
                    self.user_home / LOCAL_SHARE / "icons/hicolor/256x256/apps" / UI_ICON_FILENAME,
                )
                if self._remove_if_exists(path)
            ]
            self._prune_empty_directories()
            if not removed:
                return self._success_response(
                    UninstallationResponse,
                    "No lsfg-vk files found to remove",
                    removed_files=None,
                )
            return self._success_response(
                UninstallationResponse,
                f"lsfg-vk uninstalled successfully. Removed {len(removed)} files.",
                removed_files=removed,
            )
        except Exception as error:
            return self._error_response(
                UninstallationResponse,
                str(error),
                removed_files=None,
            )

    def cleanup_on_uninstall(self) -> bool:
        try:
            result = self.uninstall()
            if not result.get("success"):
                self.log.error(f"Error cleaning up lsfg-vk files during uninstall: {result.get('error')}")
                return False
            return True
        except Exception as error:
            self.log.error(f"Error cleaning up lsfg-vk files during uninstall: {error}")
            self.log.error(traceback.format_exc())
            return False
