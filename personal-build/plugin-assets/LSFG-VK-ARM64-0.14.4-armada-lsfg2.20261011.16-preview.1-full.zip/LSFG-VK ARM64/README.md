# LSFG-VK ARM64

**English** | [简体中文](README.zh-CN.md)

A Decky frame generation plugin for **Armada ARM64**, based on [Decky LSFG-VK](https://github.com/xXJSONDeruloXx/decky-lsfg-vk). It bundles a modified ARM64 lsfg-vk 2.0 runtime, supports Simplified Chinese, and can be installed alongside the original plugin.

[Download the latest release](https://github.com/mydanyi/decky-lsfg-vk-arm64/releases/latest) · [r16 preview release](https://github.com/mydanyi/decky-lsfg-vk-arm64/releases/tag/v0.14.4-armada-lsfg2.20261011.16-preview.1)

## Features

- Separate profiles for Steam games, non-Steam shortcuts, and supported ARM64 Flatpak applications, with bulk actions and a Now Playing page.
- Fixed frame generation from 2x through 6x, or Target FPS mode with a configurable output target and maximum multiplier from 2x through 4x. Switching modes retains both sets of settings; 1x disables generation in Fixed mode.
- Base FPS Cap from 0 (no plugin cap) through 72, applied across D3D9, D3D10, D3D11, and D3D12 through DXVK / VKD3D launch paths.
- Performance Mode defaults to enabled; explicitly saved off settings remain off. Overload Backoff and Cadence Recovery applies to Target FPS mode. Fixed mode keeps its selected multiplier and supports submission pacing from 2x through 6x.
- Automatic per-game launch-option integration using the portable wrapper `~/.lsfg-arm64`. Existing `~/lsfg-arm64` launch options remain supported during upgrade.
- Flow scale, performance mode, presentation overrides, swapchain image-count controls, and per-game compatibility options.
- An ARM64 native core, command-line utility, and configuration utility bundled in the complete plugin ZIP. The plugin installs its runtime automatically.
- Separate plugin identity, settings, wrapper, native tools, and Vulkan layer for coexistence with **Decky LSFG-VK**.
- GPU-based frame generation. Target FPS is a scheduling target, not a guarantee of performance or physical display cadence.

## Installation and usage

Requires Armada ARM64, an existing Decky installation, and a legitimate copy of **Lossless Scaling** on Steam.

1. In Steam, open **Lossless Scaling → Properties → Game Versions & Betas** (shown as **Betas** in some clients), select the **`lsfg-vk`** branch, and wait for its download or update to finish. This branch provides `lsfg-vk.dll`. See the [official lsfg-vk installation guide](https://lsfg-vk.dev/docs/installation/).
2. Download the complete plugin ZIP from [Releases](https://github.com/mydanyi/decky-lsfg-vk-arm64/releases/latest) and install it through Decky's developer settings. GitHub's automatically generated Source code downloads are source archives.
3. Open or reload **LSFG-VK ARM64**. Wait for runtime installation and Lossless Scaling detection to succeed. The Settings page includes branch setup guidance.
4. Select a game in the Steam or Non-Steam page and enable its profile. The plugin adds its launch wrapper while preserving unrelated launch options. Use the Flatpak page for supported Flatpak applications.
5. Choose Fixed or Target FPS mode, then set the Base FPS Cap and compatibility options as needed. Restart the game after launch-option, cap, or Flatpak permission changes.

Use one frame generation plugin's launch integration per game. The two plugins keep separate configurations; this fork does not automatically enroll all games, import the original plugin's settings, or delete the original plugin. When adopting a game previously configured with another frame generation wrapper, review the resulting launch options.

The release includes the modified ARM64 runtime, but not the commercial `lsfg-vk.dll`. Obtain that DLL through the Steam branch above; renaming `Lossless.dll` is not a substitute. Complete ZIPs replace earlier plugin-only packages. Release checksums, when attached, are provided in `SHA256SUMS.txt`.

## Flatpak

Flatpak integration uses a separate user-managed ARM64 Vulkan extension for supported Freedesktop 24.08 and 25.08 runtimes, including compatible GNOME / KDE derivatives. It uses the bundled ARM64 core rather than downloading the original x86 runtime. A compatible Vulkan driver and access to the required DLL remain necessary.

Application configuration and compatibility settings are tracked individually. Removing an application restores the override fields changed by this plugin while preserving unrelated settings and subsequent user edits. Existing original-plugin extensions are left in place. Changing configuration for an already running Flatpak application may require restarting that application.

Settings displays the plugin version from `package.json`. See [preview versioning](docs/PREVIEW-VERSIONING.md) and the [r16 change record](docs/CHANGELOG-r16.md).

## r16 preview timing

Installation alone does not enable the experimental present-timing path. The opt-in requires Fixed mode at 2x–6x, Present Mode Override on, an actual FIFO swapchain with a fixed refresh (FRR, not VRR), and driver support for the `VK_EXT_present_timing` features. Target FPS mode and PairPacer are not covered.

Enable it per game by adding `LSFGVK_PRESENT_TIMING=1` and `LSFGVK_GAMESCOPE_PRIMARY_DISPLAY=<the actual Gamescope primary X display>` to that game's launch environment, while preserving the existing wrapper and unrelated launch options. Do not set `:0` universally or reuse the game's own `DISPLAY`. Restart the game once after adding the environment; runtime refresh-rate and multiplier hot switches are supported once active. If the required capability is unsupported, the layer falls back to the existing path, and existing controls and performance settings are unchanged. See the [native README](native/README.md) for evidence. Tested on the KONKR with an external Gamescope PR2417; that Gamescope change is not included in the plugin.

## Development

The repository contains the Decky plugin and [native runtime patches and build notes](native/README.md). The frontend build produces `dist/index.js`; it does not compile the native runtime. Use the committed lockfile. Backend development requires Python 3.11+ and Bash on Linux.

```sh
pnpm install --frozen-lockfile
pnpm test
pnpm exec tsc --noEmit
pnpm build
python3 -m unittest discover -s tests -v
```

The package root is `LSFG-VK ARM64`. Complete packages contain `bin/lsfg-vk-arm64-2.0.0.tar.xz` with the native core, CLI, UI, layer manifest, desktop entry, and icon. `bin/liblsfg-vk-v2-arm64.so` is also retained as the packaged core artifact. See the native build notes for the archive layout and license requirements.

## Attribution and licensing

This community fork is based on [xXJSONDeruloXx/decky-lsfg-vk](https://github.com/xXJSONDeruloXx/decky-lsfg-vk). The plugin retains Kurt Himebauch's and the contributors' BSD-3-Clause license and notices; see [LICENSE](LICENSE). The [upstream README](docs/UPSTREAM-README.md) is retained for attribution and historical reference.

The [lsfg-vk](https://lsfg-vk.dev/) native component has its own CC BY-NC-ND 4.0 license, included in the release archive. The plugin license does not replace the native component's license. Lossless Scaling and its DLL remain subject to their own terms.

Thanks to the original plugin authors, lsfg-vk contributors, Lossless Scaling developers, Decky Loader team and Armada contributors. Report issues specific to this fork in [this repository](https://github.com/mydanyi/decky-lsfg-vk-arm64/issues).

## Support and community

Special thanks to **深圳市退格科技有限公司** for providing financial support for the ongoing development, testing, and maintenance of LSFG-VK ARM64.

- Sponsorship: [Afdian](https://afdian.com/a/meetmiku)
- QQ fan group: **487945399**
- QQ casual chat group: **477426414**
